#include "../src/hotkey_model.h"

#undef NDEBUG
#include <cassert>
#include <cstdio>

using namespace hotkeys;

static Combo C(unsigned mods, unsigned vk) { return Combo{ mods, vk }; }

int main() {
    // Names and parsing
    assert(ComboText(C(kCtrl | kAlt | kShift, 'M')) == L"Ctrl+Alt+Shift+M");
    assert(ComboText(C(kWin | kShift, 'S')) == L"Win+Shift+S");
    assert(ComboText(C(kCtrl, 0x70 + 11)) == L"Ctrl+F12");
    assert(ComboText(C(kCtrl | kAlt, 0)) == L"Ctrl+Alt");
    Combo c;
    assert(ParseCombo(L"ctrl + alt + shift + m", c) && c == C(kCtrl | kAlt | kShift, 'M'));
    assert(ParseCombo(L"Win+Shift+S", c) && c == C(kWin | kShift, 'S'));
    assert(ParseCombo(L"Strg+Del", c) && c == C(kCtrl, 0x2E));
    assert(ParseCombo(L"Win++", c) && c == C(kWin, 0xBB));
    assert(ParseCombo(L"Win+Num +", c) && c == C(kWin, 0x6B));
    assert(ParseCombo(L"Ctrl+Num +", c) && c == C(kCtrl, 0x6B));
    assert(ParseCombo(L"Alt+F4", c) && c == C(kAlt, 0x73));
    assert(!ParseCombo(L"Ctrl+Alt", c));
    assert(ParseCombo(L"Ctrl+Alt", c, true) && c == C(kCtrl | kAlt, 0));
    assert(!ParseCombo(L"Ctrl+M+K", c));
    assert(!ParseCombo(L"mute the mic", c, true));
    assert(!ParseCombo(L"", c, true));
    // Every combo the app can show parses back to itself.
    for (unsigned vk = 1; vk < 0xFF; vk++) {
        Combo in = C(kCtrl | kShift, vk);
        std::wstring text = ComboText(in);
        if (text.find(L"Key ") != std::wstring::npos) continue;
        Combo out;
        assert(ParseCombo(text, out) && out == in);
    }

    // Saved bindings
    Binding b;
    b.enabled = false;
    b.action = Action::DefaultDevice;
    b.combo = { kCtrl | kAlt, '1' };
    b.deviceId = L"{0.0.0.00000000}.{abc}";
    b.deviceName = L"Speakers\t(Realtek)";
    Binding r;
    assert(FromLine(ToLine(b), r));
    assert(!r.enabled && r.action == Action::DefaultDevice && r.combo == b.combo && r.deviceId == b.deviceId);
    assert(r.deviceName == L"Speakers (Realtek)");
    assert(!FromLine(L"1\t3\t3\t49", r));        // device action without a device
    assert(!FromLine(L"1\t9\t3\t49\tid\tn", r));  // unknown action
    assert(!FromLine(L"1\t0\t3\t0", r));          // no key
    assert(!FromLine(L"garbage", r));
    assert(FromLine(L"1\t0\t7\t77", r) && r.action == Action::MicMute && r.deviceId.empty());
    auto defaults = DefaultBindings(true, false);
    assert(defaults.size() == 2 && defaults[0].enabled && !defaults[1].enabled);
    assert(ComboText(defaults[0].combo) == L"Ctrl+Alt+Shift+M" && ComboText(defaults[1].combo) == L"Ctrl+Alt+Shift+D");

    // Catalog: every row parses, lookups and search work
    size_t rows = 0;
    const CatalogRow* raw = CatalogRows(rows);
    for (size_t i = 0; i < rows; i++) {
        std::wstring keys = raw[i].keys;
        size_t d = keys.find(L"Digit");
        Combo x;
        bool ok = ParseCombo(d == std::wstring::npos ? keys : keys.substr(0, d) + L"1", x);
        if (!ok) std::wprintf(L"catalog row does not parse: %ls\n", raw[i].keys);
        assert(ok);
    }
    assert(Catalog().size() > rows);  // digit rows expanded
    auto lock = Lookup(C(kWin, 'L'));
    assert(lock.size() == 1 && lock[0]->what == L"Lock the PC" && lock[0]->global);
    assert(Lookup(C(kCtrl | kAlt | kShift, 'M')).empty());  // the default mic shortcut is free
    assert(Lookup(C(kCtrl | kAlt | kShift, 'D')).empty());
    assert(!Lookup(C(kCtrl | kShift, 'M')).empty());          // Discord / Teams mute
    assert(Lookup(C(kWin, '5')).size() == 1);
    assert(Search(L"win+l").size() == 1);
    assert(Search(L"screenshot").size() >= 3);
    assert(Search(L"DISCORD").size() >= 2);
    auto winDigit = Search(L"win");
    size_t taskbarRows = 0;
    for (auto* k : winDigit) if (k->what == L"Open the pinned taskbar app in that position") taskbarRows++;
    assert(taskbarRows == 1);  // a digit group is listed once
    for (auto* k : Search(L"ctrl+alt")) assert((k->combo.mods & (kCtrl | kAlt)) == (kCtrl | kAlt));
    assert(Search(L"").size() < Catalog().size());
    assert(Search(L"zzzz-no-such-thing").empty());
    std::puts("hotkey_model_test: ok");
}
