#pragma once
// Keyboard shortcuts (global hotkeys) for the "Keyboard shortcuts" window: key names, parsing, the saved
// bindings and a searchable catalog of shortcuts Windows and common apps already use. Header-only and free
// of windows.h so tests/hotkey_model_test.cpp can check it on its own.
//
// Catalog sources: Microsoft's "Keyboard shortcuts in Windows" support page (Windows 11 and 10, read
// November 2026) for the Windows entries; the app entries are the default shortcuts of those apps.
#include <cstdlib>
#include <cwchar>
#include <cwctype>
#include <string>
#include <vector>

namespace hotkeys {

// Modifier bits, the same values as RegisterHotKey's MOD_ALT, MOD_CONTROL, MOD_SHIFT and MOD_WIN.
constexpr unsigned kAlt = 0x1, kCtrl = 0x2, kShift = 0x4, kWin = 0x8;

struct Combo {
    unsigned mods = 0;
    unsigned vk = 0;  // Windows virtual-key code; 0 = no key yet
    bool operator==(const Combo& o) const { return mods == o.mods && vk == o.vk; }
    bool operator!=(const Combo& o) const { return !(*this == o); }
};

struct KeyNameEntry { unsigned vk; const wchar_t* name; };

// Display names first; later entries with the same key are extra spellings accepted when parsing.
inline const std::vector<KeyNameEntry>& KeyNames() {
    static const std::vector<KeyNameEntry> names = [] {
        std::vector<KeyNameEntry> v = {
            { 0x08, L"Backspace" }, { 0x09, L"Tab" }, { 0x0D, L"Enter" }, { 0x13, L"Pause" }, { 0x1B, L"Esc" },
            { 0x20, L"Space" }, { 0x21, L"Page Up" }, { 0x22, L"Page Down" }, { 0x23, L"End" }, { 0x24, L"Home" },
            { 0x25, L"Left" }, { 0x26, L"Up" }, { 0x27, L"Right" }, { 0x28, L"Down" }, { 0x2C, L"PrtScn" },
            { 0x2D, L"Insert" }, { 0x2E, L"Delete" }, { 0x90, L"Num Lock" }, { 0x91, L"Scroll Lock" },
            { 0x60, L"Num 0" }, { 0x61, L"Num 1" }, { 0x62, L"Num 2" }, { 0x63, L"Num 3" }, { 0x64, L"Num 4" },
            { 0x65, L"Num 5" }, { 0x66, L"Num 6" }, { 0x67, L"Num 7" }, { 0x68, L"Num 8" }, { 0x69, L"Num 9" },
            { 0x6A, L"Num *" }, { 0x6B, L"Num +" }, { 0x6D, L"Num -" }, { 0x6E, L"Num ." }, { 0x6F, L"Num /" },
            { 0xBB, L"Plus" }, { 0xBD, L"Minus" }, { 0xBC, L"," }, { 0xBE, L"." }, { 0xBA, L";" }, { 0xBF, L"/" },
            { 0xC0, L"`" }, { 0xDB, L"[" }, { 0xDC, L"\\" }, { 0xDD, L"]" }, { 0xDE, L"'" },
            { 0xAD, L"Mute" }, { 0xAE, L"Volume Down" }, { 0xAF, L"Volume Up" }, { 0xB0, L"Next Track" },
            { 0xB1, L"Previous Track" }, { 0xB3, L"Play/Pause" },
            // extra spellings
            { 0x20, L"Spacebar" }, { 0x2E, L"Del" }, { 0x1B, L"Escape" }, { 0x21, L"PgUp" }, { 0x22, L"PgDn" },
            { 0x2C, L"Print Screen" }, { 0x0D, L"Return" }, { 0xBB, L"=" }, { 0xBD, L"-" }, { 0xBC, L"Comma" },
            { 0xBE, L"Period" }, { 0xBA, L"Semicolon" }, { 0xBF, L"Slash" },
        };
        static const wchar_t* fkeys[] = { L"F1", L"F2", L"F3", L"F4", L"F5", L"F6", L"F7", L"F8", L"F9", L"F10", L"F11", L"F12",
                                          L"F13", L"F14", L"F15", L"F16", L"F17", L"F18", L"F19", L"F20", L"F21", L"F22", L"F23", L"F24" };
        for (unsigned i = 0; i < 24; i++) v.push_back({ 0x70 + i, fkeys[i] });
        return v;
    }();
    return names;
}

inline std::wstring KeyName(unsigned vk) {
    if ((vk >= 'A' && vk <= 'Z') || (vk >= '0' && vk <= '9')) return std::wstring(1, (wchar_t)vk);
    for (auto& k : KeyNames())
        if (k.vk == vk) return k.name;
    wchar_t buf[16];
    swprintf(buf, 16, L"Key %02X", vk);
    return buf;
}

// "Win+Ctrl+Alt+Shift+K", the order Microsoft's shortcut lists use.
inline std::wstring ComboText(const Combo& c) {
    std::wstring s;
    if (c.mods & kWin) s += L"Win+";
    if (c.mods & kCtrl) s += L"Ctrl+";
    if (c.mods & kAlt) s += L"Alt+";
    if (c.mods & kShift) s += L"Shift+";
    if (c.vk) s += KeyName(c.vk);
    else if (!s.empty()) s.pop_back();
    return s;
}

inline std::wstring Lower(std::wstring s) {
    for (auto& ch : s) ch = (wchar_t)std::towlower(ch);
    return s;
}

inline std::wstring Trim(const std::wstring& s) {
    size_t a = s.find_first_not_of(L" \t"), b = s.find_last_not_of(L" \t");
    return a == std::wstring::npos ? L"" : s.substr(a, b - a + 1);
}

// One part of a combo: a modifier name sets `mod`, a key name sets `vk`. False for anything else.
inline bool ParsePart(const std::wstring& raw, unsigned& mod, unsigned& vk) {
    std::wstring p = Lower(Trim(raw));
    mod = 0; vk = 0;
    if (p.empty()) return false;
    if (p == L"ctrl" || p == L"control" || p == L"strg") { mod = kCtrl; return true; }
    if (p == L"alt") { mod = kAlt; return true; }
    if (p == L"shift") { mod = kShift; return true; }
    if (p == L"win" || p == L"windows" || p == L"windows key" || p == L"meta") { mod = kWin; return true; }
    if (p.size() == 1 && ((p[0] >= L'a' && p[0] <= L'z') || (p[0] >= L'0' && p[0] <= L'9'))) { vk = (unsigned)std::towupper(p[0]); return true; }
    for (auto& k : KeyNames())
        if (Lower(k.name) == p) { vk = k.vk; return true; }
    return false;
}

// "Ctrl+Alt+M", "win + shift + s", "Ctrl+Plus". A trailing "+" alone means the Plus key ("Win++").
// `partial` accepts modifiers without a key ("Ctrl+Alt"). False when any part is not a key name.
inline bool ParseCombo(const std::wstring& text, Combo& out, bool partial = false) {
    std::wstring t = Trim(text);
    if (t.empty()) return false;
    std::vector<std::wstring> raw;
    for (size_t start = 0;;) {
        size_t plus = t.find(L'+', start);
        raw.push_back(t.substr(start, plus == std::wstring::npos ? std::wstring::npos : plus - start));
        if (plus == std::wstring::npos) break;
        start = plus + 1;
    }
    // An empty piece is a "+" that is itself a key: "Num +" or "Win++".
    std::vector<std::wstring> parts;
    for (size_t i = 0; i < raw.size(); i++) {
        std::wstring piece = Trim(raw[i]);
        if (!piece.empty()) { parts.push_back(piece); continue; }
        if (!parts.empty() && Lower(parts.back()) == L"num") { parts.back() = L"Num +"; continue; }
        if (i + 1 < raw.size() && Trim(raw[i + 1]).empty()) { parts.push_back(L"Plus"); i++; continue; }
        return false;
    }
    Combo c;
    for (auto& part : parts) {
        unsigned mod = 0, vk = 0;
        if (!ParsePart(part, mod, vk)) return false;
        if (vk && c.vk) return false;  // two keys
        c.mods |= mod;
        if (vk) c.vk = vk;
    }
    if (!c.vk && (!partial || !c.mods)) return false;
    out = c;
    return true;
}

// ---- saved bindings -----------------------------------------------------------------------------

enum class Action { MicMute = 0, Deafen = 1, MuteDevice = 2, DefaultDevice = 3 };

struct Binding {
    bool enabled = true;
    Action action = Action::MicMute;
    Combo combo;
    std::wstring deviceId;    // MuteDevice / DefaultDevice: the Core Audio endpoint id
    std::wstring deviceName;  // shown while the device is unplugged
};

inline bool NeedsDevice(Action a) { return a == Action::MuteDevice || a == Action::DefaultDevice; }

inline Combo DefaultCombo(Action a) {
    return { kCtrl | kAlt | kShift, a == Action::Deafen ? (unsigned)'D' : (unsigned)'M' };
}

// The two shortcuts the app starts with; `micOn`/`deafenOn` carry over the earlier on/off settings.
inline std::vector<Binding> DefaultBindings(bool micOn, bool deafenOn) {
    Binding mic, deafen;
    mic.enabled = micOn;
    mic.action = Action::MicMute;
    mic.combo = DefaultCombo(Action::MicMute);
    deafen.enabled = deafenOn;
    deafen.action = Action::Deafen;
    deafen.combo = DefaultCombo(Action::Deafen);
    return { mic, deafen };
}

// One REG_MULTI_SZ entry: "enabled<TAB>action<TAB>mods<TAB>vk<TAB>device id<TAB>device name".
inline std::wstring ToLine(const Binding& b) {
    std::wstring name = b.deviceName;
    for (auto& ch : name) if (ch == L'\t' || ch == L'\n' || ch == L'\r') ch = L' ';
    return std::wstring(b.enabled ? L"1" : L"0") + L"\t" + std::to_wstring((int)b.action) + L"\t" + std::to_wstring(b.combo.mods) +
           L"\t" + std::to_wstring(b.combo.vk) + L"\t" + b.deviceId + L"\t" + name;
}

inline bool FromLine(const std::wstring& line, Binding& out) {
    std::vector<std::wstring> f;
    size_t start = 0;
    for (;;) {
        size_t tab = line.find(L'\t', start);
        f.push_back(line.substr(start, tab == std::wstring::npos ? std::wstring::npos : tab - start));
        if (tab == std::wstring::npos) break;
        start = tab + 1;
    }
    if (f.size() < 4) return false;
    auto num = [](const std::wstring& s, long& v) {
        if (s.empty()) return false;
        wchar_t* end = nullptr;
        v = wcstol(s.c_str(), &end, 10);
        return end && !*end;
    };
    long en, act, mods, vk;
    if (!num(f[0], en) || !num(f[1], act) || !num(f[2], mods) || !num(f[3], vk)) return false;
    if (act < 0 || act > 3 || mods < 0 || mods > 0xF || vk <= 0 || vk > 0xFE) return false;
    Binding b;
    b.enabled = en != 0;
    b.action = (Action)act;
    b.combo = { (unsigned)mods, (unsigned)vk };
    if (f.size() > 4) b.deviceId = f[4];
    if (f.size() > 5) b.deviceName = f[5];
    if (NeedsDevice(b.action) && b.deviceId.empty()) return false;
    out = b;
    return true;
}

// ---- catalog of shortcuts already in use --------------------------------------------------------

struct KnownShortcut {
    Combo combo;
    std::wstring keys;   // as listed ("Win+Digit (1-9)" stays one row)
    std::wstring what;
    std::wstring where;  // "Windows", "File Explorer", "Discord", ...
    bool global;         // works in every app (Windows, overlays); false = only while that app is in front
};

struct CatalogRow { const wchar_t* keys; const wchar_t* what; const wchar_t* where; bool global; };

inline const CatalogRow* CatalogRows(size_t& count) {
    static const CatalogRow rows[] = {
        // Windows key (Microsoft support page)
        { L"Win+A", L"Open Quick Settings", L"Windows", true },
        { L"Win+Shift+A", L"Focus a Windows tip", L"Windows", true },
        { L"Win+B", L"Focus the notification area", L"Windows", true },
        { L"Win+Alt+B", L"Turn HDR on or off", L"Windows", true },
        { L"Win+C", L"Open Copilot (or search)", L"Windows", true },
        { L"Win+Ctrl+C", L"Turn color filters on or off", L"Windows", true },
        { L"Win+Shift+C", L"Open the charms menu (Windows 10)", L"Windows", true },
        { L"Win+D", L"Show or hide the desktop", L"Windows", true },
        { L"Win+Alt+D", L"Show or hide date and time on the desktop", L"Windows", true },
        { L"Win+Ctrl+D", L"Add a virtual desktop", L"Windows", true },
        { L"Win+E", L"Open File Explorer", L"Windows", true },
        { L"Win+Esc", L"Close Magnifier", L"Windows", true },
        { L"Win+F", L"Open Feedback Hub", L"Windows", true },
        { L"Win+Ctrl+F", L"Search for devices on a network", L"Windows", true },
        { L"Win+Ctrl+F4", L"Close the current virtual desktop", L"Windows", true },
        { L"Win+G", L"Open Xbox Game Bar", L"Windows", true },
        { L"Win+H", L"Open voice typing", L"Windows", true },
        { L"Win+Alt+H", L"Focus the voice typing keyboard", L"Windows", true },
        { L"Win+Home", L"Minimize all but the active window", L"Windows", true },
        { L"Win+I", L"Open Settings", L"Windows", true },
        { L"Win+J", L"Open Recall (where available)", L"Windows", true },
        { L"Win+K", L"Cast to a display", L"Windows", true },
        { L"Win+Alt+K", L"Mute or unmute the microphone in supported apps", L"Windows", true },
        { L"Win+L", L"Lock the PC", L"Windows", true },
        { L"Win+M", L"Minimize all windows", L"Windows", true },
        { L"Win+Shift+M", L"Restore minimized windows", L"Windows", true },
        { L"Win+N", L"Open notifications and calendar", L"Windows", true },
        { L"Win+Ctrl+N", L"Open Narrator settings", L"Windows", true },
        { L"Win+O", L"Lock the screen orientation", L"Windows", true },
        { L"Win+Ctrl+O", L"Turn on the On-Screen Keyboard", L"Windows", true },
        { L"Win+P", L"Choose a display mode (project)", L"Windows", true },
        { L"Win+Pause", L"Open Settings > System > About", L"Windows", true },
        { L"Win+PrtScn", L"Save a full-screen screenshot", L"Windows", true },
        { L"Win+Q", L"Open search", L"Windows", true },
        { L"Win+Ctrl+Q", L"Open Quick Assist", L"Windows", true },
        { L"Win+R", L"Open the Run dialog", L"Windows", true },
        { L"Win+Shift+R", L"Record a screen region (Snipping Tool)", L"Windows", true },
        { L"Win+S", L"Open search", L"Windows", true },
        { L"Win+Ctrl+S", L"Turn on Windows Speech Recognition", L"Windows", true },
        { L"Win+Shift+S", L"Screenshot of part of the screen", L"Windows", true },
        { L"Win+T", L"Cycle through taskbar apps", L"Windows", true },
        { L"Win+Shift+T", L"Previous taskbar app", L"Windows", true },
        { L"Win+U", L"Open Accessibility settings", L"Windows", true },
        { L"Win+V", L"Open clipboard history", L"Windows", true },
        { L"Win+Ctrl+V", L"Open the sound output quick settings", L"Windows", true },
        { L"Win+Shift+V", L"Cycle through notifications", L"Windows", true },
        { L"Win+W", L"Open Widgets", L"Windows", true },
        { L"Win+X", L"Open the Quick Link menu", L"Windows", true },
        { L"Win+Y", L"Switch between Mixed Reality and desktop", L"Windows", true },
        { L"Win+Z", L"Open snap layouts", L"Windows", true },
        { L"Win+Tab", L"Open Task View", L"Windows", true },
        { L"Win+Space", L"Next input language", L"Windows", true },
        { L"Win+Shift+Space", L"Previous input language", L"Windows", true },
        { L"Win+Ctrl+Space", L"Previous input option", L"Windows", true },
        { L"Win+Ctrl+Enter", L"Turn Narrator on or off", L"Windows", true },
        { L"Win+Shift+Enter", L"Make a UWP app full screen", L"Windows", true },
        { L"Win+Alt+Enter", L"Open taskbar settings", L"Windows", true },
        { L"Win+Ctrl+Shift+B", L"Wake the screen when it is blank", L"Windows", true },
        { L"Win+,", L"Peek at the desktop", L"Windows", true },
        { L"Win+.", L"Open the emoji panel", L"Windows", true },
        { L"Win+;", L"Open the emoji panel", L"Windows", true },
        { L"Win+/", L"Start IME reconversion", L"Windows", true },
        { L"Win+Plus", L"Magnifier: zoom in", L"Windows", true },
        { L"Win+Num +", L"Magnifier: zoom in", L"Windows", true },
        { L"Win+Minus", L"Magnifier: zoom out", L"Windows", true },
        { L"Win+Num -", L"Magnifier: zoom out", L"Windows", true },
        { L"Win+Up", L"Maximize the window", L"Windows", true },
        { L"Win+Down", L"Minimize or restore the window", L"Windows", true },
        { L"Win+Left", L"Snap the window left", L"Windows", true },
        { L"Win+Right", L"Snap the window right", L"Windows", true },
        { L"Win+Alt+Up", L"Snap the window to the top half", L"Windows", true },
        { L"Win+Alt+Down", L"Snap the window to the bottom half", L"Windows", true },
        { L"Win+Shift+Up", L"Stretch the window to the top and bottom", L"Windows", true },
        { L"Win+Shift+Down", L"Restore a snapped or maximized window", L"Windows", true },
        { L"Win+Shift+Left", L"Move the window to the left monitor", L"Windows", true },
        { L"Win+Shift+Right", L"Move the window to the right monitor", L"Windows", true },
        { L"Win+Ctrl+Left", L"Previous virtual desktop", L"Windows", true },
        { L"Win+Ctrl+Right", L"Next virtual desktop", L"Windows", true },
        { L"Win+Digit", L"Open the pinned taskbar app in that position", L"Windows", true },
        { L"Win+Shift+Digit", L"New window of the pinned taskbar app", L"Windows", true },
        { L"Win+Ctrl+Digit", L"Last window of the pinned taskbar app", L"Windows", true },
        { L"Win+Alt+Digit", L"Jump list of the pinned taskbar app", L"Windows", true },
        { L"Win+Ctrl+Shift+Digit", L"Pinned taskbar app as administrator", L"Windows", true },
        // General Windows shortcuts
        { L"Ctrl+Alt+Delete", L"Security screen (lock, sign out, Task Manager)", L"Windows", true },
        { L"Ctrl+Shift+Esc", L"Open Task Manager", L"Windows", true },
        { L"Ctrl+Esc", L"Open Start", L"Windows", true },
        { L"Ctrl+Alt+Tab", L"Show open apps and stay open", L"Windows", true },
        { L"Alt+Tab", L"Switch between open windows", L"Windows", true },
        { L"Alt+Shift+Tab", L"Switch between open windows, backwards", L"Windows", true },
        { L"Alt+Esc", L"Cycle through windows in opening order", L"Windows", true },
        { L"Alt+F4", L"Close the active window", L"Windows", true },
        { L"Alt+Space", L"Window menu (also PowerToys Run)", L"Windows", true },
        { L"Alt+PrtScn", L"Screenshot of the active window", L"Windows", true },
        { L"Alt+Enter", L"Properties of the selected item", L"Windows", false },
        { L"Alt+Left", L"Go back", L"Windows", false },
        { L"Alt+Right", L"Go forward", L"Windows", false },
        { L"Alt+Up", L"Up one folder", L"File Explorer", false },
        { L"Alt+F8", L"Show the password on the sign-in screen", L"Windows", false },
        { L"Ctrl+Alt+Insert", L"Leave Windows Sandbox focus", L"Windows", true },
        { L"Ctrl+Space", L"Turn the Chinese IME on or off", L"Windows", true },
        { L"Shift+F10", L"Context menu of the selected item", L"Windows", false },
        { L"Shift+Delete", L"Delete without the Recycle Bin", L"Windows", false },
        // Text editing and almost every app
        { L"Ctrl+A", L"Select all", L"Most apps", false },
        { L"Ctrl+B", L"Bold", L"Most apps", false },
        { L"Ctrl+C", L"Copy", L"Most apps", false },
        { L"Ctrl+D", L"Delete to Recycle Bin / bookmark in browsers", L"Most apps", false },
        { L"Ctrl+E", L"Search box (File Explorer)", L"Most apps", false },
        { L"Ctrl+F", L"Find", L"Most apps", false },
        { L"Ctrl+H", L"Replace / history in browsers", L"Most apps", false },
        { L"Ctrl+I", L"Italic", L"Most apps", false },
        { L"Ctrl+J", L"Downloads (browsers)", L"Most apps", false },
        { L"Ctrl+K", L"Insert link / quick search (Discord, Slack, browsers)", L"Most apps", false },
        { L"Ctrl+L", L"Address bar", L"Most apps", false },
        { L"Ctrl+N", L"New window", L"Most apps", false },
        { L"Ctrl+O", L"Open", L"Most apps", false },
        { L"Ctrl+P", L"Print", L"Most apps", false },
        { L"Ctrl+R", L"Refresh", L"Most apps", false },
        { L"Ctrl+S", L"Save", L"Most apps", false },
        { L"Ctrl+T", L"New tab", L"Most apps", false },
        { L"Ctrl+U", L"Underline", L"Most apps", false },
        { L"Ctrl+V", L"Paste", L"Most apps", false },
        { L"Ctrl+W", L"Close the tab", L"Most apps", false },
        { L"Ctrl+X", L"Cut", L"Most apps", false },
        { L"Ctrl+Y", L"Redo", L"Most apps", false },
        { L"Ctrl+Z", L"Undo", L"Most apps", false },
        { L"Ctrl+Shift+V", L"Paste as plain text", L"Most apps", false },
        { L"Ctrl+Insert", L"Copy", L"Most apps", false },
        { L"Shift+Insert", L"Paste", L"Most apps", false },
        { L"Ctrl+Backspace", L"Delete the word to the left", L"Most apps", false },
        { L"Ctrl+Delete", L"Delete the word to the right", L"Most apps", false },
        { L"Ctrl+Tab", L"Next tab", L"Most apps", false },
        { L"Ctrl+Shift+Tab", L"Previous tab", L"Most apps", false },
        { L"Ctrl+F4", L"Close the document or tab", L"Most apps", false },
        { L"Ctrl+F5", L"Refresh", L"Most apps", false },
        { L"Ctrl+Plus", L"Zoom in", L"Most apps", false },
        { L"Ctrl+Minus", L"Zoom out", L"Most apps", false },
        { L"Ctrl+0", L"Reset zoom", L"Most apps", false },
        { L"Ctrl+Digit", L"Go to that tab", L"Most apps", false },
        { L"Ctrl+Left", L"Previous word", L"Most apps", false },
        { L"Ctrl+Right", L"Next word", L"Most apps", false },
        { L"Ctrl+Up", L"Previous paragraph", L"Most apps", false },
        { L"Ctrl+Down", L"Next paragraph", L"Most apps", false },
        { L"Ctrl+Home", L"Start of the document", L"Most apps", false },
        { L"Ctrl+End", L"End of the document", L"Most apps", false },
        { L"Ctrl+Shift+Left", L"Select the previous word", L"Most apps", false },
        { L"Ctrl+Shift+Right", L"Select the next word", L"Most apps", false },
        { L"Ctrl+Shift+Home", L"Select to the start", L"Most apps", false },
        { L"Ctrl+Shift+End", L"Select to the end", L"Most apps", false },
        // File Explorer
        { L"Alt+D", L"Address bar", L"File Explorer", false },
        { L"Alt+P", L"Preview pane", L"File Explorer", false },
        { L"Alt+Shift+P", L"Details pane", L"File Explorer", false },
        { L"Ctrl+Shift+E", L"Expand all folders (also AMD: record video)", L"File Explorer", false },
        { L"Ctrl+Shift+N", L"New folder / private window in browsers", L"File Explorer", false },
        { L"Ctrl+Shift+Digit", L"Change the view", L"File Explorer", false },
        // Browsers
        { L"Ctrl+Shift+T", L"Reopen the closed tab", L"Browsers", false },
        { L"Ctrl+Shift+Delete", L"Clear browsing data", L"Browsers", false },
        { L"Ctrl+Shift+I", L"Developer tools (also AMD: screenshot)", L"Browsers", false },
        { L"Ctrl+Shift+J", L"Console / downloads", L"Browsers", false },
        { L"Ctrl+Shift+B", L"Bookmarks bar", L"Browsers", false },
        { L"Ctrl+Shift+P", L"Private window (Firefox) / command palette (VS Code)", L"Browsers", false },
        // Voice and meeting apps
        { L"Ctrl+Shift+M", L"Mute the microphone", L"Discord, Teams", false },
        { L"Ctrl+Shift+D", L"Deafen", L"Discord", false },
        { L"Ctrl+Shift+O", L"Camera on or off (Teams) / AMD metrics overlay", L"Teams", false },
        { L"Ctrl+Shift+K", L"Raise your hand", L"Teams", false },
        { L"Alt+A", L"Mute the microphone", L"Zoom", false },
        { L"Alt+V", L"Camera on or off", L"Zoom", false },
        // Overlays that take the keys everywhere
        { L"Win+Alt+R", L"Start or stop recording", L"Xbox Game Bar", true },
        { L"Win+Alt+G", L"Record the last 30 seconds", L"Xbox Game Bar", true },
        { L"Win+Alt+M", L"Microphone on or off while recording", L"Xbox Game Bar", true },
        { L"Win+Alt+T", L"Show or hide the recording timer", L"Xbox Game Bar", true },
        { L"Win+Alt+PrtScn", L"Screenshot of the game", L"Xbox Game Bar", true },
        { L"Alt+Z", L"Open the overlay", L"NVIDIA overlay", true },
        { L"Alt+F1", L"Screenshot", L"NVIDIA overlay", true },
        { L"Alt+F9", L"Start or stop recording", L"NVIDIA overlay", true },
        { L"Alt+F10", L"Save instant replay", L"NVIDIA overlay", true },
        { L"Alt+R", L"Performance overlay (NVIDIA) / open AMD Software", L"NVIDIA, AMD", true },
        { L"Ctrl+Shift+S", L"Save instant replay (AMD) / save as in apps", L"AMD Software", true },
        { L"Shift+Tab", L"Steam overlay (in games)", L"Steam", false },
        { L"Win+Ctrl+T", L"Keep the window on top", L"PowerToys", true },
        { L"Win+Shift+/", L"Shortcut guide", L"PowerToys", true },
    };
    count = sizeof(rows) / sizeof(rows[0]);
    return rows;
}

// The catalog with each row's combo parsed; "Digit" rows become one entry per digit.
inline const std::vector<KnownShortcut>& Catalog() {
    static const std::vector<KnownShortcut> list = [] {
        std::vector<KnownShortcut> v;
        size_t n = 0;
        const CatalogRow* rows = CatalogRows(n);
        for (size_t i = 0; i < n; i++) {
            std::wstring keys = rows[i].keys;
            size_t d = keys.find(L"Digit");
            if (d != std::wstring::npos) {
                for (wchar_t digit = L'0'; digit <= L'9'; digit++) {
                    Combo c;
                    if (ParseCombo(keys.substr(0, d) + digit, c)) v.push_back({ c, keys.substr(0, d) + L"1-9, 0", rows[i].what, rows[i].where, rows[i].global });
                }
                continue;
            }
            Combo c;
            if (ParseCombo(keys, c)) v.push_back({ c, ComboText(c), rows[i].what, rows[i].where, rows[i].global });
        }
        return v;
    }();
    return list;
}

inline std::vector<const KnownShortcut*> Lookup(const Combo& c) {
    std::vector<const KnownShortcut*> hits;
    for (auto& k : Catalog())
        if (k.combo == c) hits.push_back(&k);
    return hits;
}

// Search box: a combo ("ctrl+alt+m") finds that exact shortcut, modifiers alone ("ctrl+alt") find every
// shortcut using them, anything else matches words in the keys, the description or the app.
// Rows of a "Digit" group are shown once.
inline std::vector<const KnownShortcut*> Search(const std::wstring& query) {
    std::vector<const KnownShortcut*> hits;
    std::wstring q = Lower(Trim(query));
    Combo c;
    bool isCombo = !q.empty() && ParseCombo(q, c, true);
    std::wstring lastGroup;
    for (auto& k : Catalog()) {
        bool match;
        if (q.empty()) match = true;
        else if (isCombo && c.vk) match = k.combo == c;
        else if (isCombo) match = (k.combo.mods & c.mods) == c.mods;
        else match = Lower(k.keys).find(q) != std::wstring::npos || Lower(k.what).find(q) != std::wstring::npos ||
                     Lower(k.where).find(q) != std::wstring::npos;
        if (!match) continue;
        bool group = k.keys.find(L"1-9, 0") != std::wstring::npos;
        if (group && !(isCombo && c.vk)) {
            std::wstring id = k.keys + k.what;
            if (id == lastGroup) continue;
            lastGroup = id;
        }
        hits.push_back(&k);
    }
    return hits;
}

}  // namespace hotkeys
