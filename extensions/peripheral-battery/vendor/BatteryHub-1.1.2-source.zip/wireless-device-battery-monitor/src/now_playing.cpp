#include "now_playing.h"

#include "i18n.h"
#include "media_session.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <string>
#include <vector>

namespace {

constexpr UINT WM_MEDIA = WM_APP + 1;  // from media_session: the snapshot changed
constexpr UINT_PTR kPlaceTimer = 1;    // follows the battery strip / tray and survives an Explorer restart, every second
constexpr ULONGLONG kNoteMs = 5000;    // how long "Nothing playing" shows after the strip is turned on
const wchar_t* kClass = L"WirelessBatteryNowPlaying";

HINSTANCE g_inst;
HWND g_wnd, g_bar;  // the strip, and the taskbar it lives in
bool g_light;
bool g_enabled;
ULONGLONG g_noteUntil;  // show "Nothing playing" until then, so turning the strip on always shows something
media_session::Snapshot g_snap;

// Layout of the last render (strip pixels), for hit testing.
enum Button { kNone = -1, kPrev, kPlay, kNext, kButtons };
RECT g_buttons[kButtons];
bool g_buttonOn[kButtons];
int g_hot = kNone, g_pressed = kNone;
bool g_tracking;
SIZE g_size{};
RECT g_placed{};  // where it was last put (taskbar client coordinates)

struct Rgb { int r, g, b; };

int g_dpi = 96;
int Px(int v) { return MulDiv(v, g_dpi, 96); }

HFONT MakeFont(int px, int weight, const wchar_t* face, const wchar_t* fallback) {
    for (const wchar_t* f : { face, fallback }) {
        // Grayscale smoothing: the text is drawn as a coverage mask over the transparent taskbar.
        HFONT h = CreateFontW(-px, 0, 0, 0, weight, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                              ANTIALIASED_QUALITY, DEFAULT_PITCH, f);
        HDC dc = CreateCompatibleDC(nullptr);
        HGDIOBJ o = SelectObject(dc, h);
        wchar_t got[LF_FACESIZE] = {};
        GetTextFaceW(dc, LF_FACESIZE, got);
        SelectObject(dc, o);
        DeleteDC(dc);
        if (!_wcsicmp(got, f) || f == fallback) return h;
        DeleteObject(h);
    }
    return nullptr;
}

// Coverage (0..1) of pixel (x, y) by a rounded rectangle, anti-aliased at the corners.
double Cover(int x, int y, int x0, int y0, int w, int h, int r) {
    if (x < x0 || y < y0 || x >= x0 + w || y >= y0 + h) return 0;
    double dx = x < x0 + r ? x0 + r - (x + 0.5) : (x >= x0 + w - r ? (x + 0.5) - (x0 + w - r) : 0);
    double dy = y < y0 + r ? y0 + r - (y + 0.5) : (y >= y0 + h - r ? (y + 0.5) - (y0 + h - r) : 0);
    if (dx <= 0 || dy <= 0) return 1;
    return std::min(1.0, std::max(0.0, r - std::sqrt(dx * dx + dy * dy) + 0.5));
}

// Premultiplied BGRA canvas over the transparent taskbar.
struct Canvas {
    int w, h;
    std::vector<uint32_t> px;
    Canvas(int w_, int h_) : w(w_), h(h_), px((size_t)w_ * h_, 0) {}
    // Source-over of a premultiplied colour (b, g, r, a in 0..255).
    void Over(int x, int y, double b, double g, double r, double a) {
        if (x < 0 || y < 0 || x >= w || y >= h || a <= 0) return;
        uint32_t& p = px[(size_t)y * w + x];
        double k = 1 - a / 255.0;
        int nb = (int)std::lround(b + (p & 0xFF) * k), ng = (int)std::lround(g + ((p >> 8) & 0xFF) * k);
        int nr = (int)std::lround(r + ((p >> 16) & 0xFF) * k), na = (int)std::lround(a + (p >> 24) * k);
        p = (uint32_t)std::min(na, 255) << 24 | (uint32_t)std::min(nr, 255) << 16 | (uint32_t)std::min(ng, 255) << 8 | (uint32_t)std::min(nb, 255);
    }
    void Blend(int x, int y, Rgb c, double a) {  // a: 0..1
        a = std::min(a, 1.0) * 255;
        Over(x, y, c.b * a / 255, c.g * a / 255, c.r * a / 255, a);
    }
    void Round(int x0, int y0, int rw, int rh, int r, Rgb c, double a) {
        for (int y = y0; y < y0 + rh; y++)
            for (int x = x0; x < x0 + rw; x++) Blend(x, y, c, a * Cover(x, y, x0, y0, rw, rh, r));
    }
};

// The art (square, premultiplied BGRA) scaled down by area averaging into a rounded square.
void DrawArt(Canvas& cv, const media_session::Snapshot& s, int x0, int y0, int size, int radius) {
    const int n = s.artSize;
    for (int y = 0; y < size; y++) {
        double sy0 = (double)y * n / size, sy1 = (double)(y + 1) * n / size;
        for (int x = 0; x < size; x++) {
            double sx0 = (double)x * n / size, sx1 = (double)(x + 1) * n / size;
            double acc[4] = {}, wsum = 0;
            for (int yy = (int)sy0; yy < (int)std::ceil(sy1) && yy < n; yy++) {
                double wy = std::min(sy1, yy + 1.0) - std::max(sy0, (double)yy);
                for (int xx = (int)sx0; xx < (int)std::ceil(sx1) && xx < n; xx++) {
                    double wgt = wy * (std::min(sx1, xx + 1.0) - std::max(sx0, (double)xx));
                    uint32_t p = s.art[(size_t)yy * n + xx];
                    acc[0] += wgt * (p & 0xFF);
                    acc[1] += wgt * ((p >> 8) & 0xFF);
                    acc[2] += wgt * ((p >> 16) & 0xFF);
                    acc[3] += wgt * (p >> 24);
                    wsum += wgt;
                }
            }
            if (wsum <= 0) continue;
            double k = Cover(x0 + x, y0 + y, x0, y0, size, size, radius) / wsum;
            cv.Over(x0 + x, y0 + y, acc[0] * k, acc[1] * k, acc[2] * k, acc[3] * k);
        }
    }
}

// Text in `c`, laid out by DrawTextW in rectangle `r`: drawn white on black as a coverage mask, then blended.
void Text(Canvas& cv, const std::wstring& s, HFONT f, Rgb c, RECT r, UINT flags) {
    int w = r.right - r.left, h = r.bottom - r.top;
    if (w <= 0 || h <= 0 || s.empty()) return;
    HDC dc = CreateCompatibleDC(nullptr);
    BITMAPINFO bi{};
    bi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, -h, 1, 32, BI_RGB };
    void* bits = nullptr;
    HBITMAP bmp = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!bmp) { DeleteDC(dc); return; }
    HGDIOBJ ob = SelectObject(dc, bmp), of = SelectObject(dc, f);
    memset(bits, 0, (size_t)w * h * 4);
    SetBkMode(dc, TRANSPARENT);
    SetTextColor(dc, RGB(255, 255, 255));
    RECT local{ 0, 0, w, h };
    DrawTextW(dc, s.c_str(), (int)s.size(), &local, flags | DT_SINGLELINE | DT_NOPREFIX | DT_END_ELLIPSIS);
    GdiFlush();
    const auto* p = static_cast<const uint32_t*>(bits);
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            uint32_t v = p[(size_t)y * w + x];
            int cov = std::max({ (int)(v & 0xFF), (int)((v >> 8) & 0xFF), (int)((v >> 16) & 0xFF) });
            if (cov) cv.Blend(r.left + x, r.top + y, c, cov / 255.0);
        }
    SelectObject(dc, of);
    SelectObject(dc, ob);
    DeleteObject(bmp);
    DeleteDC(dc);
}

HWND Taskbar() { return FindWindowW(L"Shell_TrayWnd", nullptr); }

int BarDpi(HWND bar) {
    using Fn = UINT(WINAPI*)(HWND);
    static Fn fn = reinterpret_cast<Fn>(reinterpret_cast<void*>(GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetDpiForWindow")));
    UINT d = fn ? fn(bar) : 96;
    return d ? (int)d : 96;
}

// Where the strip's right edge goes (screen x): left of the battery strip and of other apps' small taskbar
// widgets packed against the notification area, or of the notification area itself. -1 = nowhere (vertical
// or right-to-left taskbar, not laid out yet).
int RightEdge(HWND bar, RECT& barRect) {
    if (!GetWindowRect(bar, &barRect) || barRect.bottom - barRect.top > barRect.right - barRect.left) return -1;
    if (GetWindowLongW(bar, GWL_EXSTYLE) & WS_EX_LAYOUTRTL) return -1;
    HWND tray = FindWindowExW(bar, nullptr, L"TrayNotifyWnd", nullptr);
    RECT tr{};
    if (!tray || !GetWindowRect(tray, &tr) || tr.right <= tr.left) return -1;
    int edge = tr.left;
    DWORD explorer = 0, pid = 0;
    GetWindowThreadProcessId(bar, &explorer);
    const LONG span = barRect.right - barRect.left;
    std::vector<RECT> others;  // the battery strip and other apps' widgets in the taskbar
    for (HWND c = GetWindow(bar, GW_CHILD); c; c = GetWindow(c, GW_HWNDNEXT)) {
        RECT r;
        if (c == g_wnd || !IsWindowVisible(c) || !GetWindowRect(c, &r) || r.right <= r.left) continue;
        GetWindowThreadProcessId(c, &pid);
        if (pid == explorer || r.right - r.left > span / 3) continue;
        others.push_back(r);
    }
    // Windows 10 News and Interests / weather sits right next to the tray.
    for (const wchar_t* cls : { L"ShellFeedsTaskbarViewWindow", L"DynamicContent2" }) {
        HWND feeds = FindWindowExW(bar, nullptr, cls, nullptr);
        RECT fr;
        if (feeds && IsWindowVisible(feeds) && GetWindowRect(feeds, &fr) && fr.right > fr.left) others.push_back(fr);
    }
    const int slack = MulDiv(16, BarDpi(bar), 96);
    for (int pass = 0; pass < 8; pass++) {
        bool moved = false;
        for (const RECT& r : others)
            if (r.right >= edge - slack && r.right <= edge + slack / 4 && r.left < edge) edge = r.left, moved = true;
        if (!moved) break;
    }
    return edge;
}

bool Wanted() { return g_enabled && (g_snap.active || GetTickCount64() < g_noteUntil); }

void Hide() {
    if (g_wnd && IsWindowVisible(g_wnd)) ShowWindow(g_wnd, SW_HIDE);
    g_hot = g_pressed = kNone;
    g_placed = RECT{};
}

// Creates the strip in the current taskbar, again after Explorer restarts (the old one went with it).
bool EnsureWindow() {
    HWND bar = Taskbar();
    if (!bar) return false;
    if (g_wnd && IsWindow(g_wnd) && g_bar == bar) return true;
    if (g_wnd && IsWindow(g_wnd)) DestroyWindow(g_wnd);
    g_wnd = CreateWindowExW(WS_EX_LAYERED | WS_EX_NOACTIVATE, kClass, L"", WS_CHILD | WS_CLIPSIBLINGS, 0, 0, 1, 1, bar, nullptr, g_inst, nullptr);
    g_bar = g_wnd ? bar : nullptr;
    g_placed = RECT{};
    if (g_wnd) SetTimer(g_wnd, kPlaceTimer, 1000, nullptr);
    return g_wnd != nullptr;
}

void Render() {
    if (!g_enabled || !EnsureWindow()) return;
    if (!Wanted()) { Hide(); return; }
    RECT barRect{}, client{};
    int edge = RightEdge(g_bar, barRect);
    if (edge < 0 || !GetClientRect(g_bar, &client) || client.bottom <= 0) { Hide(); return; }
    g_dpi = BarDpi(g_bar);

    // Taskbar colours, like the battery strip: dark text on a light taskbar, light text on a dark one.
    Rgb fg = g_light ? Rgb{ 0, 0, 0 } : Rgb{ 255, 255, 255 };
    Rgb sub = g_light ? Rgb{ 70, 70, 70 } : Rgb{ 200, 200, 200 };
    Rgb off = g_light ? Rgb{ 160, 160, 160 } : Rgb{ 110, 110, 110 };
    Rgb plate = g_light ? Rgb{ 0, 0, 0 } : Rgb{ 255, 255, 255 };

    const bool message = !g_snap.active;
    const int H = client.bottom;
    const int art = std::max(Px(16), std::min(Px(36), H - Px(10)));
    const int textW = Px(message ? 110 : 150), bw = Px(30), gap = Px(8);
    const int W = message ? Px(4) + Px(20) + Px(6) + textW : Px(4) + art + gap + textW + Px(4) + 3 * bw + Px(2);
    Canvas cv(W, H);
    // Nearly invisible fill so the whole strip takes the mouse (fully transparent pixels let clicks through).
    for (auto& p : cv.px) p = 0x01000000u;

    HFONT icons = MakeFont(Px(14), FW_NORMAL, L"Segoe Fluent Icons", L"Segoe MDL2 Assets");
    HFONT bigIcon = MakeFont(Px(18), FW_NORMAL, L"Segoe Fluent Icons", L"Segoe MDL2 Assets");
    HFONT title = MakeFont(Px(12), FW_SEMIBOLD, L"Segoe UI Variable Text", L"Segoe UI");
    HFONT body = MakeFont(Px(11), FW_NORMAL, L"Segoe UI Variable Text", L"Segoe UI");

    for (auto& b : g_buttons) b = RECT{};
    if (message) {
        Text(cv, std::wstring(1, (wchar_t)0xEC4F), icons, sub, RECT{ Px(4), 0, Px(24), H }, DT_CENTER | DT_VCENTER);  // MusicNote
        Text(cv, T(L"Nothing playing"), body, sub, RECT{ Px(30), 0, W, H }, DT_LEFT | DT_VCENTER);
    } else {
        const int ay = (H - art) / 2;
        if (g_snap.artSize > 0) {
            DrawArt(cv, g_snap, Px(4), ay, art, Px(4));
        } else {
            cv.Round(Px(4), ay, art, art, Px(4), plate, g_light ? 0.08 : 0.12);
            Text(cv, std::wstring(1, (wchar_t)0xEC4F), bigIcon, sub, RECT{ Px(4), ay, Px(4) + art, ay + art }, DT_CENTER | DT_VCENTER);
        }
        // title over artist (or the app when there is no artist), centred as a pair
        const int tx = Px(4) + art + gap, lineT = Px(16), lineB = Px(15);
        const int ty = (H - lineT - lineB) / 2;
        std::wstring second = g_snap.artist.empty() ? g_snap.app : g_snap.artist;
        Text(cv, g_snap.title.empty() ? g_snap.app : g_snap.title, title, fg, RECT{ tx, ty, tx + textW, ty + lineT }, DT_LEFT | DT_TOP);
        Text(cv, second, body, sub, RECT{ tx, ty + lineT, tx + textW, ty + lineT + lineB }, DT_LEFT | DT_TOP);
        // previous / play-pause / next
        const wchar_t glyphs[kButtons] = { 0xE892, (wchar_t)(g_snap.playing ? 0xE769 : 0xE768), 0xE893 };  // Previous, Pause / Play, Next
        g_buttonOn[kPrev] = g_snap.canPrevious;
        g_buttonOn[kPlay] = g_snap.canPlayPause;
        g_buttonOn[kNext] = g_snap.canNext;
        const int bh = std::min(H - Px(8), Px(32)), by = (H - bh) / 2;
        int bx = tx + textW + Px(4);
        for (int i = 0; i < kButtons; i++) {
            g_buttons[i] = RECT{ bx, by, bx + bw, by + bh };
            if (g_buttonOn[i] && (g_hot == i || g_pressed == i))
                cv.Round(bx, by, bw, bh, Px(4), plate, g_pressed == i ? (g_light ? 0.06 : 0.05) : (g_light ? 0.09 : 0.11));
            Text(cv, std::wstring(1, glyphs[i]), icons, g_buttonOn[i] ? fg : off, g_buttons[i], DT_CENTER | DT_VCENTER);
            bx += bw;
        }
    }
    for (HFONT f : { icons, bigIcon, title, body }) DeleteObject(f);

    // Place it: right edge against the battery strip / tray, in taskbar client coordinates.
    POINT p{ edge, barRect.top };
    ScreenToClient(g_bar, &p);
    int left = p.x - W - Px(4);
    if (left < 0) { Hide(); return; }

    HDC screen = GetDC(nullptr);
    HDC mem = CreateCompatibleDC(screen);
    BITMAPINFO bi{};
    bi.bmiHeader = { sizeof(BITMAPINFOHEADER), W, -H, 1, 32, BI_RGB };
    void* bits = nullptr;
    HBITMAP bmp = CreateDIBSection(mem, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (bmp) {
        memcpy(bits, cv.px.data(), (size_t)W * H * 4);
        HGDIOBJ ob = SelectObject(mem, bmp);
        SIZE sz{ W, H };
        POINT src{ 0, 0 };
        BLENDFUNCTION bf{ AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };
        SetWindowPos(g_wnd, HWND_TOP, left, 0, W, H, SWP_NOACTIVATE);
        UpdateLayeredWindow(g_wnd, screen, nullptr, &sz, mem, &src, 0, &bf, ULW_ALPHA);
        SelectObject(mem, ob);
        DeleteObject(bmp);
        g_size = sz;
        g_placed = RECT{ left, 0, left + W, H };
        if (!IsWindowVisible(g_wnd)) ShowWindow(g_wnd, SW_SHOWNOACTIVATE);
    }
    DeleteDC(mem);
    ReleaseDC(nullptr, screen);
}

int ButtonAt(POINT p) {
    for (int i = 0; i < kButtons; i++)
        if (g_buttonOn[i] && PtInRect(&g_buttons[i], p)) return i;
    return kNone;
}

LRESULT CALLBACK Proc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_TIMER:
            if (wp == kPlaceTimer) {
                // Follow the battery strip and the tray as they change width; re-render only when the spot moved,
                // the taskbar's size or DPI changed, or the "Nothing playing" note ran out.
                RECT barRect{}, client{};
                int edge = g_bar ? RightEdge(g_bar, barRect) : -1;
                bool moved = true;
                if (edge >= 0 && GetClientRect(g_bar, &client)) {
                    POINT p{ edge, barRect.top };
                    ScreenToClient(g_bar, &p);
                    moved = p.x - g_size.cx - Px(4) != g_placed.left || client.bottom != g_placed.bottom || BarDpi(g_bar) != g_dpi;
                }
                if (Wanted() != (IsWindowVisible(h) != FALSE) || (Wanted() && moved)) Render();
            }
            return 0;
        case WM_MOUSEACTIVATE:
            return MA_NOACTIVATE;
        case WM_MOUSEMOVE: {
            POINT p{ (short)LOWORD(lp), (short)HIWORD(lp) };
            if (!g_tracking) {
                TRACKMOUSEEVENT t{ sizeof(t), TME_LEAVE, h, 0 };
                g_tracking = TrackMouseEvent(&t) != FALSE;
            }
            int hot = ButtonAt(p);
            if (hot != g_hot) {
                g_hot = hot;
                Render();
            }
            return 0;
        }
        case WM_MOUSELEAVE:
            g_tracking = false;
            if (g_hot != kNone) {
                g_hot = kNone;
                Render();
            }
            return 0;
        case WM_LBUTTONDOWN: {
            POINT p{ (short)LOWORD(lp), (short)HIWORD(lp) };
            g_pressed = ButtonAt(p);
            if (g_pressed != kNone) {
                SetCapture(h);
                Render();
            }
            return 0;
        }
        case WM_LBUTTONUP: {
            POINT p{ (short)LOWORD(lp), (short)HIWORD(lp) };
            int b = g_pressed;  // read first: ReleaseCapture sends WM_CAPTURECHANGED, which clears it
            ReleaseCapture();
            g_pressed = kNone;
            if (b != kNone) {
                if (ButtonAt(p) == b)
                    media_session::Send(b == kPrev ? media_session::Command::Previous
                                        : b == kNext ? media_session::Command::Next
                                                     : media_session::Command::PlayPause);
                Render();
            }
            return 0;
        }
        case WM_CAPTURECHANGED:
            g_pressed = kNone;
            return 0;
        case WM_DESTROY:
            if (h == g_wnd) {
                g_wnd = nullptr;
                g_bar = nullptr;
            }
            return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}

// Receives the snapshot notices: a message-only window, so they keep arriving while the strip is
// hidden or being re-created after an Explorer restart.
HWND g_sink;
LRESULT CALLBACK SinkProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_MEDIA) {
        g_snap = media_session::Get();
        Render();
        return 0;
    }
    if (msg == WM_TIMER) {  // the strip is gone (Explorer restarted, or hidden before it was ever created)
        if (g_enabled && Wanted() && (!g_wnd || !IsWindow(g_wnd))) Render();
        return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}

}  // namespace

namespace now_playing {

void Enable(HINSTANCE inst, bool lightTheme, bool announce) {
    g_light = lightTheme;
    if (g_enabled) return;
    g_inst = inst;
    static bool registered = false;
    if (!registered) {
        WNDCLASSEXW wc{ sizeof(wc) };
        wc.lpfnWndProc = Proc;
        wc.hInstance = inst;
        wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));  // IDC_ARROW
        wc.lpszClassName = kClass;
        WNDCLASSEXW sink{ sizeof(sink) };
        sink.lpfnWndProc = SinkProc;
        sink.hInstance = inst;
        sink.lpszClassName = L"WirelessBatteryNowPlayingSink";
        registered = RegisterClassExW(&wc) != 0 && RegisterClassExW(&sink) != 0;
    }
    if (!g_sink) g_sink = CreateWindowExW(0, L"WirelessBatteryNowPlayingSink", L"", 0, 0, 0, 0, 0, HWND_MESSAGE, nullptr, inst, nullptr);
    if (!g_sink) return;
    g_enabled = true;
    g_noteUntil = announce ? GetTickCount64() + kNoteMs : 0;
    g_snap = media_session::Snapshot{};
    SetTimer(g_sink, 1, 2000, nullptr);
    media_session::Start(g_sink, WM_MEDIA);
    Render();
}

void Disable() {
    if (!g_enabled) return;
    g_enabled = false;
    media_session::Stop();
    if (g_sink) KillTimer(g_sink, 1);
    if (g_wnd && IsWindow(g_wnd)) DestroyWindow(g_wnd);
    g_wnd = g_bar = nullptr;
    g_snap = media_session::Snapshot{};
}

bool Enabled() { return g_enabled; }

void SetLightTheme(bool light) {
    if (g_light == light) return;
    g_light = light;
    Render();
}

}  // namespace now_playing
