#pragma once
// Mutes or unmutes the default microphone or the default playback device (deafen) with Core Audio,
// for the global mute hotkeys in main.cpp. Both default roles (eConsole and eCommunications) are set,
// so apps that record or play on either one follow. Also watches the default microphone for the
// tray microphone icon.
#include <windows.h>

#include <string>
#include <vector>

namespace audio_mute {

enum class Flow { Capture, Render };

// Flips the mute state of the default endpoint for the flow; returns 1 = now muted, 0 = now unmuted,
// -1 = no default device or Core Audio failed. Safe to call on the UI thread.
int Toggle(Flow flow);

// The default endpoint's mute state: 1 = muted, 0 = not muted, -1 = no default device.
int GetMute(Flow flow);

// The audio devices that are plugged in and enabled, playback and recording.
struct Device {
    std::wstring id;    // Core Audio endpoint id; stays the same across restarts
    std::wstring name;  // "Headset Microphone (HyperX Cloud III Wireless)"
    bool capture;       // true = microphone / recording device
};
std::vector<Device> ListDevices();
std::wstring DeviceName(const std::wstring& id);  // "" when the device is not there

// Flips the mute state of one device; returns 1 = now muted, 0 = now unmuted, -1 = device not found.
int ToggleDevice(const std::wstring& id);

// Makes the device the Windows default for its direction (all roles: apps, communications, system sounds).
bool SetDefault(const std::wstring& id);

// Posts `msg` to `hwnd` whenever the default microphone's mute state changes, whoever changed it
// (wParam 0), or the default microphone itself changes or is plugged in or out (wParam 1: call Rebind()
// on the UI thread, then read GetMute). Call Watch, Rebind and Unwatch on the UI thread.
bool Watch(HWND hwnd, UINT msg);
void Rebind();
void Unwatch();

}  // namespace audio_mute
