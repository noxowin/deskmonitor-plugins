#pragma once
// "Keyboard shortcuts" window: change the mute shortcuts, add shortcuts that mute a chosen audio device or
// make it the default, and search the shortcuts Windows and common apps already use.
#include <windows.h>

#include <vector>

#include "hotkey_model.h"

namespace shortcuts_dialog {

// Modal. The caller should drop its own hotkeys first, so pressing them reaches the key box instead of
// firing. Returns true when the user saved; `bindings` then holds the new list.
bool Show(HWND owner, std::vector<hotkeys::Binding>& bindings);

}  // namespace shortcuts_dialog
