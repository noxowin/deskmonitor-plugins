#include "audio_mute.h"

#include <windows.h>
#include <cwchar>
#include <initializer_list>
#include <mmdeviceapi.h>
#include <endpointvolume.h>

namespace audio_mute {
namespace {

IAudioEndpointVolume* DefaultVolume(IMMDeviceEnumerator* en, EDataFlow flow, ERole role, LPWSTR* id) {
    IMMDevice* dev = nullptr;
    if (FAILED(en->GetDefaultAudioEndpoint(flow, role, &dev)) || !dev) return nullptr;
    IAudioEndpointVolume* vol = nullptr;
    if (FAILED(dev->Activate(__uuidof(IAudioEndpointVolume), CLSCTX_INPROC_SERVER, nullptr, (void**)&vol))) vol = nullptr;
    if (vol && id && FAILED(dev->GetId(id))) *id = nullptr;
    dev->Release();
    return vol;
}

IMMDeviceEnumerator* NewEnumerator() {
    IMMDeviceEnumerator* en = nullptr;
    if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_INPROC_SERVER, __uuidof(IMMDeviceEnumerator),
                                (void**)&en)))
        en = nullptr;
    return en;
}

// Receives Core Audio's notifications on its own threads and only posts them to the window; all COM work
// (rebinding to a new default microphone) happens on the UI thread in Rebind(). One static instance,
// so reference counting is a no-op.
class Watcher final : public IMMNotificationClient, public IAudioEndpointVolumeCallback {
public:
    HWND hwnd = nullptr;
    UINT msg = 0;
    IMMDeviceEnumerator* en = nullptr;
    IAudioEndpointVolume* vol = nullptr;  // the default microphone, while there is one
    bool comInit = false;

    void Post(bool deviceChanged) { if (hwnd) PostMessageW(hwnd, msg, deviceChanged ? 1 : 0, 0); }

    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, void** out) override {
        if (!out) return E_POINTER;
        if (iid == __uuidof(IUnknown) || iid == __uuidof(IMMNotificationClient)) *out = static_cast<IMMNotificationClient*>(this);
        else if (iid == __uuidof(IAudioEndpointVolumeCallback)) *out = static_cast<IAudioEndpointVolumeCallback*>(this);
        else { *out = nullptr; return E_NOINTERFACE; }
        return S_OK;
    }
    ULONG STDMETHODCALLTYPE AddRef() override { return 1; }
    ULONG STDMETHODCALLTYPE Release() override { return 1; }

    HRESULT STDMETHODCALLTYPE OnNotify(PAUDIO_VOLUME_NOTIFICATION_DATA) override { Post(false); return S_OK; }
    HRESULT STDMETHODCALLTYPE OnDefaultDeviceChanged(EDataFlow flow, ERole role, LPCWSTR) override {
        if (flow == eCapture && role == eConsole) Post(true);
        return S_OK;
    }
    HRESULT STDMETHODCALLTYPE OnDeviceStateChanged(LPCWSTR, DWORD) override { Post(true); return S_OK; }
    HRESULT STDMETHODCALLTYPE OnDeviceAdded(LPCWSTR) override { return S_OK; }
    HRESULT STDMETHODCALLTYPE OnDeviceRemoved(LPCWSTR) override { return S_OK; }
    HRESULT STDMETHODCALLTYPE OnPropertyValueChanged(LPCWSTR, const PROPERTYKEY) override { return S_OK; }

    void DropVolume() {
        if (!vol) return;
        vol->UnregisterControlChangeNotify(this);
        vol->Release();
        vol = nullptr;
    }
} g_watcher;

}  // namespace

int Toggle(Flow flow) {
    HRESULT init = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    int result = -1;
    if (IMMDeviceEnumerator* en = NewEnumerator()) {
        EDataFlow f = flow == Flow::Capture ? eCapture : eRender;
        LPWSTR consoleId = nullptr, commsId = nullptr;
        IAudioEndpointVolume* console = DefaultVolume(en, f, eConsole, &consoleId);
        IAudioEndpointVolume* comms = DefaultVolume(en, f, eCommunications, &commsId);
        // The state follows the main default device; the communications default follows it when it differs.
        IAudioEndpointVolume* lead = console ? console : comms;
        BOOL muted = FALSE;
        if (lead && SUCCEEDED(lead->GetMute(&muted))) {
            BOOL target = muted ? FALSE : TRUE;
            if (SUCCEEDED(lead->SetMute(target, nullptr))) {
                result = target ? 1 : 0;
                bool same = consoleId && commsId && wcscmp(consoleId, commsId) == 0;
                if (console && comms && !same) comms->SetMute(target, nullptr);
            }
        }
        if (console) console->Release();
        if (comms) comms->Release();
        CoTaskMemFree(consoleId);
        CoTaskMemFree(commsId);
        en->Release();
    }
    if (SUCCEEDED(init)) CoUninitialize();
    return result;
}

int GetMute(Flow flow) {
    HRESULT init = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    int result = -1;
    if (IMMDeviceEnumerator* en = NewEnumerator()) {
        if (IAudioEndpointVolume* vol = DefaultVolume(en, flow == Flow::Capture ? eCapture : eRender, eConsole, nullptr)) {
            BOOL muted = FALSE;
            if (SUCCEEDED(vol->GetMute(&muted))) result = muted ? 1 : 0;
            vol->Release();
        }
        en->Release();
    }
    if (SUCCEEDED(init)) CoUninitialize();
    return result;
}

// IPolicyConfig: the interface the Windows Sound control panel uses to set the default device. It is not in
// the SDK; this layout (Windows 7 and later) is the one audio switchers have used for years. Only
// SetDefaultEndpoint is called; the methods before it are declared to keep the vtable order.
// Not in the anonymous namespace: there GCC sees a class nothing in the program implements, decides the
// virtual call can never happen and optimizes it away (the -Os build crashed on SetDefaultEndpoint).
struct IPolicyConfigLocal : public IUnknown {
    virtual HRESULT STDMETHODCALLTYPE GetMixFormat(PCWSTR, void**) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetDeviceFormat(PCWSTR, INT, void**) = 0;
    virtual HRESULT STDMETHODCALLTYPE ResetDeviceFormat(PCWSTR) = 0;
    virtual HRESULT STDMETHODCALLTYPE SetDeviceFormat(PCWSTR, void*, void*) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetProcessingPeriod(PCWSTR, INT, void*, void*) = 0;
    virtual HRESULT STDMETHODCALLTYPE SetProcessingPeriod(PCWSTR, void*) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetShareMode(PCWSTR, void*) = 0;
    virtual HRESULT STDMETHODCALLTYPE SetShareMode(PCWSTR, void*) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetPropertyValue(PCWSTR, const PROPERTYKEY&, PROPVARIANT*) = 0;
    virtual HRESULT STDMETHODCALLTYPE SetPropertyValue(PCWSTR, const PROPERTYKEY&, PROPVARIANT*) = 0;
    virtual HRESULT STDMETHODCALLTYPE SetDefaultEndpoint(PCWSTR, ERole) = 0;
    virtual HRESULT STDMETHODCALLTYPE SetEndpointVisibility(PCWSTR, INT) = 0;
};

namespace {

// PKEY_Device_FriendlyName {A45C254E-DF1C-4EFD-8020-67D146A850E0}, 14
const PROPERTYKEY kFriendlyName = { { 0xA45C254E, 0xDF1C, 0x4EFD, { 0x80, 0x20, 0x67, 0xD1, 0x46, 0xA8, 0x50, 0xE0 } }, 14 };
const CLSID kPolicyConfigClient = { 0x870AF99C, 0x171D, 0x4F9E, { 0xAF, 0x0D, 0xE6, 0x3D, 0xF4, 0x0C, 0x2B, 0xC9 } };
const IID kIidPolicyConfig = { 0xF8679F50, 0x850A, 0x41CF, { 0x9C, 0x72, 0x43, 0x0F, 0x29, 0x02, 0x90, 0xC8 } };

std::wstring FriendlyName(IMMDevice* dev) {
    std::wstring name;
    IPropertyStore* props = nullptr;
    if (SUCCEEDED(dev->OpenPropertyStore(STGM_READ, &props)) && props) {
        PROPVARIANT pv;
        PropVariantInit(&pv);
        if (SUCCEEDED(props->GetValue(kFriendlyName, &pv)) && pv.vt == VT_LPWSTR && pv.pwszVal) name = pv.pwszVal;
        PropVariantClear(&pv);
        props->Release();
    }
    return name;
}

// The device with this id if it is plugged in and enabled.
IMMDevice* ActiveDevice(IMMDeviceEnumerator* en, const std::wstring& id) {
    IMMDevice* dev = nullptr;
    DWORD state = 0;
    if (id.empty() || FAILED(en->GetDevice(id.c_str(), &dev)) || !dev) return nullptr;
    if (FAILED(dev->GetState(&state)) || state != DEVICE_STATE_ACTIVE) { dev->Release(); return nullptr; }
    return dev;
}

}  // namespace

std::vector<Device> ListDevices() {
    std::vector<Device> list;
    HRESULT init = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    if (IMMDeviceEnumerator* en = NewEnumerator()) {
        for (EDataFlow flow : { eRender, eCapture }) {
            IMMDeviceCollection* all = nullptr;
            UINT count = 0;
            if (FAILED(en->EnumAudioEndpoints(flow, DEVICE_STATE_ACTIVE, &all)) || !all) continue;
            all->GetCount(&count);
            for (UINT i = 0; i < count; i++) {
                IMMDevice* dev = nullptr;
                LPWSTR id = nullptr;
                if (SUCCEEDED(all->Item(i, &dev)) && dev && SUCCEEDED(dev->GetId(&id)) && id)
                    list.push_back({ id, FriendlyName(dev), flow == eCapture });
                CoTaskMemFree(id);
                if (dev) dev->Release();
            }
            all->Release();
        }
        en->Release();
    }
    if (SUCCEEDED(init)) CoUninitialize();
    return list;
}

std::wstring DeviceName(const std::wstring& id) {
    std::wstring name;
    HRESULT init = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    if (IMMDeviceEnumerator* en = NewEnumerator()) {
        if (IMMDevice* dev = ActiveDevice(en, id)) {
            name = FriendlyName(dev);
            dev->Release();
        }
        en->Release();
    }
    if (SUCCEEDED(init)) CoUninitialize();
    return name;
}

int ToggleDevice(const std::wstring& id) {
    int result = -1;
    HRESULT init = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    if (IMMDeviceEnumerator* en = NewEnumerator()) {
        if (IMMDevice* dev = ActiveDevice(en, id)) {
            IAudioEndpointVolume* vol = nullptr;
            BOOL muted = FALSE;
            if (SUCCEEDED(dev->Activate(__uuidof(IAudioEndpointVolume), CLSCTX_INPROC_SERVER, nullptr, (void**)&vol)) && vol) {
                if (SUCCEEDED(vol->GetMute(&muted)) && SUCCEEDED(vol->SetMute(muted ? FALSE : TRUE, nullptr))) result = muted ? 0 : 1;
                vol->Release();
            }
            dev->Release();
        }
        en->Release();
    }
    if (SUCCEEDED(init)) CoUninitialize();
    return result;
}

bool SetDefault(const std::wstring& id) {
    bool ok = false;
    HRESULT init = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    IMMDeviceEnumerator* en = NewEnumerator();
    IMMDevice* dev = en ? ActiveDevice(en, id) : nullptr;
    IPolicyConfigLocal* policy = nullptr;
    if (dev && SUCCEEDED(CoCreateInstance(kPolicyConfigClient, nullptr, CLSCTX_ALL, kIidPolicyConfig, (void**)&policy)) && policy) {
        ok = true;
        for (ERole role : { eConsole, eMultimedia, eCommunications })
            ok = SUCCEEDED(policy->SetDefaultEndpoint(id.c_str(), role)) && ok;
        policy->Release();
    }
    if (dev) dev->Release();
    if (en) en->Release();
    if (SUCCEEDED(init)) CoUninitialize();
    return ok;
}

bool Watch(HWND hwnd, UINT msg) {
    Watcher& w = g_watcher;
    if (w.en) return true;
    HRESULT init = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    w.comInit = SUCCEEDED(init);
    w.en = NewEnumerator();
    if (!w.en || FAILED(w.en->RegisterEndpointNotificationCallback(&w))) {
        if (w.en) { w.en->Release(); w.en = nullptr; }
        if (w.comInit) { CoUninitialize(); w.comInit = false; }
        return false;
    }
    w.hwnd = hwnd;
    w.msg = msg;
    Rebind();
    return true;
}

void Rebind() {
    Watcher& w = g_watcher;
    if (!w.en) return;
    w.DropVolume();
    w.vol = DefaultVolume(w.en, eCapture, eConsole, nullptr);
    if (w.vol && FAILED(w.vol->RegisterControlChangeNotify(&w))) { w.vol->Release(); w.vol = nullptr; }
}

void Unwatch() {
    Watcher& w = g_watcher;
    if (!w.en) return;
    w.DropVolume();
    w.en->UnregisterEndpointNotificationCallback(&w);
    w.en->Release();
    w.en = nullptr;
    w.hwnd = nullptr;
    if (w.comInit) { CoUninitialize(); w.comInit = false; }
}

}  // namespace audio_mute
