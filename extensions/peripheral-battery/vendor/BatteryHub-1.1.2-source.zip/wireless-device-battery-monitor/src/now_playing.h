#pragma once
// "Now playing" on the taskbar (menu option, off by default): a strip just left of the battery strip (or of the
// notification area in tray-icon mode) with the cover art, the title and the artist (or the source app) of
// whatever Windows says is playing, and previous / play-pause / next buttons. A button the source does not
// offer is greyed out. The strip hides when nothing is playing; on a left / right or right-to-left taskbar it
// stays hidden.
#include <windows.h>

namespace now_playing {

// `announce`: turned on from the menu, so show "Nothing playing" for a moment when nothing is.
void Enable(HINSTANCE inst, bool lightTheme, bool announce);
void Disable();
bool Enabled();
void SetLightTheme(bool light);

}  // namespace now_playing
