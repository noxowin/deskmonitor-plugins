#include "shortcuts_dialog.h"

#include <commctrl.h>

#include <algorithm>
#include <string>

#include "audio_mute.h"
#include "i18n.h"

namespace shortcuts_dialog {
namespace {

using hotkeys::Action;
using hotkeys::Binding;
using hotkeys::Combo;

constexpr wchar_t kWindowClass[] = L"WirelessBatteryShortcutsDialog";
constexpr int kProbeHotkeyId = 0xBFFE;
enum : int {
    IDC_LIST = 100, IDC_ACTION, IDC_DEVICE, IDC_KEYS, IDC_STATUS, IDC_ADD, IDC_UPDATE, IDC_REMOVE, IDC_SEARCH, IDC_CATALOG, IDC_COUNT,
};
enum class Level { Neutral, Good, Warn, Bad };

struct State {
    std::vector<Binding> list;
    std::vector<audio_mute::Device> devices;
    std::vector<std::wstring> deviceChoiceIds;  // device combo item -> endpoint id
    std::vector<std::wstring> deviceChoiceNames;
    HWND bindings = nullptr, action = nullptr, device = nullptr, keys = nullptr, status = nullptr;
    HWND search = nullptr, catalog = nullptr, count = nullptr;
    HFONT font = nullptr, bold = nullptr;
    Level level = Level::Neutral;
    bool filling = false;
    bool accepted = false;
};

State* Get(HWND h) { return reinterpret_cast<State*>(GetWindowLongPtrW(h, GWLP_USERDATA)); }

const wchar_t* ActionText(Action a) {
    switch (a) {
        case Action::MicMute: return T(L"Mute the default microphone");
        case Action::Deafen: return T(L"Mute the default speakers or headset (deafen)");
        case Action::MuteDevice: return T(L"Mute a device");
        default: return T(L"Make a device the default");
    }
}

std::wstring DeviceLabel(const audio_mute::Device& d) {
    return d.name + L" (" + (d.capture ? T(L"microphone") : T(L"speakers or headset")) + L")";
}

std::wstring BindingDevice(const State& s, const Binding& b) {
    if (!hotkeys::NeedsDevice(b.action)) return T(L"Windows default");
    for (auto& d : s.devices)
        if (d.id == b.deviceId) return DeviceLabel(d);
    return b.deviceName + L" (" + T(L"not connected") + L")";
}

// Whether another program (or Windows) already holds the combination. This program's own shortcuts are
// unregistered while the window is open, so they don't count.
bool KeyFree(HWND h, const Combo& c) {
    if (!RegisterHotKey(h, kProbeHotkeyId, c.mods | MOD_NOREPEAT, c.vk)) return false;
    UnregisterHotKey(h, kProbeHotkeyId);
    return true;
}

Combo ReadKeys(const State& s) {
    WORD v = (WORD)SendMessageW(s.keys, HKM_GETHOTKEY, 0, 0);
    BYTE flags = HIBYTE(v);
    Combo c;
    c.vk = LOBYTE(v);
    if (flags & HOTKEYF_CONTROL) c.mods |= hotkeys::kCtrl;
    if (flags & HOTKEYF_ALT) c.mods |= hotkeys::kAlt;
    if (flags & HOTKEYF_SHIFT) c.mods |= hotkeys::kShift;
    return c;
}

void WriteKeys(const State& s, const Combo& c) {
    BYTE flags = 0;
    if (c.mods & hotkeys::kCtrl) flags |= HOTKEYF_CONTROL;
    if (c.mods & hotkeys::kAlt) flags |= HOTKEYF_ALT;
    if (c.mods & hotkeys::kShift) flags |= HOTKEYF_SHIFT;
    bool ext = (c.vk >= VK_PRIOR && c.vk <= VK_DOWN) || c.vk == VK_INSERT || c.vk == VK_DELETE || c.vk == VK_DIVIDE;
    if (ext) flags |= HOTKEYF_EXT;
    SendMessageW(s.keys, HKM_SETHOTKEY, MAKEWORD(c.vk, flags), 0);
}

int Selected(const State& s) { return (int)SendMessageW(s.bindings, LVM_GETNEXTITEM, (WPARAM)-1, LVNI_SELECTED); }

// What the status line says about a combination; `skip` is the shortcut being edited (-1 = a new one).
std::wstring Judge(HWND h, const State& s, const Combo& c, int skip, Level& level) {
    if (!c.vk) { level = Level::Neutral; return T(L"Click the box and press the keys for the shortcut."); }
    for (size_t i = 0; i < s.list.size(); i++)
        if ((int)i != skip && s.list[i].combo == c) { level = Level::Bad; return T(L"Another BatteryHub shortcut already uses these keys."); }
    auto hits = hotkeys::Lookup(c);
    if (!KeyFree(h, c)) {
        level = Level::Bad;
        if (!hits.empty())
            return TF(L"Already in use, probably by {app}: {what}", { { L"app", hits.front()->where }, { L"what", hits.front()->what } });
        return T(L"Windows or another running app already uses these keys.");
    }
    if (hits.empty()) { level = Level::Good; return T(L"Free: nothing known uses these keys."); }
    const auto* k = hits.front();
    level = Level::Warn;
    if (k->global)
        return TF(L"{app} uses this when it runs: {what}", { { L"app", k->where }, { L"what", k->what } });
    return TF(L"Inside {app}: {what}. BatteryHub would take these keys from it.", { { L"app", k->where }, { L"what", k->what } });
}

void SetStatus(HWND h, State& s) {
    int sel = Selected(s);
    s.level = Level::Neutral;
    std::wstring text = Judge(h, s, ReadKeys(s), sel, s.level);
    SetWindowTextW(s.status, text.c_str());
    InvalidateRect(s.status, nullptr, TRUE);
}

void FillCatalog(State& s) {
    wchar_t q[128] = {};
    GetWindowTextW(s.search, q, ARRAYSIZE(q));
    auto hits = hotkeys::Search(q);
    SendMessageW(s.catalog, WM_SETREDRAW, FALSE, 0);
    SendMessageW(s.catalog, LVM_DELETEALLITEMS, 0, 0);
    int row = 0;
    for (auto* k : hits) {
        LVITEMW it{};
        it.mask = LVIF_TEXT;
        it.iItem = row;
        it.pszText = const_cast<wchar_t*>(k->keys.c_str());
        SendMessageW(s.catalog, LVM_INSERTITEMW, 0, (LPARAM)&it);
        std::wstring what = k->what, where = k->where + (k->global ? L"" : std::wstring(L" (") + T(L"in the app") + L")");
        it.iSubItem = 1; it.pszText = const_cast<wchar_t*>(what.c_str());
        SendMessageW(s.catalog, LVM_SETITEMTEXTW, row, (LPARAM)&it);
        it.iSubItem = 2; it.pszText = const_cast<wchar_t*>(where.c_str());
        SendMessageW(s.catalog, LVM_SETITEMTEXTW, row, (LPARAM)&it);
        row++;
    }
    SendMessageW(s.catalog, WM_SETREDRAW, TRUE, 0);
    InvalidateRect(s.catalog, nullptr, TRUE);
    std::wstring n = hits.empty() ? std::wstring(T(L"Nothing known uses that.")) : TF(L"{count} found", { { L"count", std::to_wstring(hits.size()) } });
    SetWindowTextW(s.count, n.c_str());
}

void FillBindings(HWND h, State& s, int select) {
    s.filling = true;
    SendMessageW(s.bindings, LVM_DELETEALLITEMS, 0, 0);
    for (size_t i = 0; i < s.list.size(); i++) {
        const Binding& b = s.list[i];
        std::wstring cols[4] = { ActionText(b.action), BindingDevice(s, b), hotkeys::ComboText(b.combo), L"" };
        if (!b.enabled) cols[3] = T(L"Off");
        else if (!KeyFree(h, b.combo)) cols[3] = T(L"Keys used elsewhere");
        else cols[3] = T(L"On");
        LVITEMW it{};
        it.mask = LVIF_TEXT;
        it.iItem = (int)i;
        it.pszText = const_cast<wchar_t*>(cols[0].c_str());
        SendMessageW(s.bindings, LVM_INSERTITEMW, 0, (LPARAM)&it);
        for (int c = 1; c < 4; c++) {
            it.iSubItem = c;
            it.pszText = const_cast<wchar_t*>(cols[c].c_str());
            SendMessageW(s.bindings, LVM_SETITEMTEXTW, i, (LPARAM)&it);
        }
        ListView_SetCheckState(s.bindings, (int)i, b.enabled);
    }
    if (select >= 0 && select < (int)s.list.size()) {
        ListView_SetItemState(s.bindings, select, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
        ListView_EnsureVisible(s.bindings, select, FALSE);
    }
    s.filling = false;
    BOOL any = Selected(s) >= 0;
    EnableWindow(GetDlgItem(h, IDC_UPDATE), any);
    EnableWindow(GetDlgItem(h, IDC_REMOVE), any);
}

// Device choices for the chosen action; keeps `keepId` selected, listing it as "not connected" if needed.
void FillDevices(State& s, const std::wstring& keepId, const std::wstring& keepName) {
    Action a = (Action)SendMessageW(s.action, CB_GETCURSEL, 0, 0);
    bool needs = hotkeys::NeedsDevice(a);
    SendMessageW(s.device, CB_RESETCONTENT, 0, 0);
    s.deviceChoiceIds.clear();
    s.deviceChoiceNames.clear();
    EnableWindow(s.device, needs);
    if (!needs) {
        SendMessageW(s.device, CB_ADDSTRING, 0, (LPARAM)T(L"Windows default"));
        SendMessageW(s.device, CB_SETCURSEL, 0, 0);
        return;
    }
    int sel = -1;
    for (auto& d : s.devices) {
        std::wstring label = DeviceLabel(d);
        SendMessageW(s.device, CB_ADDSTRING, 0, (LPARAM)label.c_str());
        if (d.id == keepId) sel = (int)s.deviceChoiceIds.size();
        s.deviceChoiceIds.push_back(d.id);
        s.deviceChoiceNames.push_back(d.name);
    }
    if (sel < 0 && !keepId.empty()) {
        std::wstring label = keepName + L" (" + T(L"not connected") + L")";
        SendMessageW(s.device, CB_ADDSTRING, 0, (LPARAM)label.c_str());
        sel = (int)s.deviceChoiceIds.size();
        s.deviceChoiceIds.push_back(keepId);
        s.deviceChoiceNames.push_back(keepName);
    }
    if (s.deviceChoiceIds.empty()) SendMessageW(s.device, CB_ADDSTRING, 0, (LPARAM)T(L"No audio devices found"));
    SendMessageW(s.device, CB_SETCURSEL, sel >= 0 ? sel : 0, 0);
}

void LoadEditor(HWND h, State& s, int index) {
    if (index < 0 || index >= (int)s.list.size()) return;
    const Binding& b = s.list[index];
    SendMessageW(s.action, CB_SETCURSEL, (WPARAM)b.action, 0);
    FillDevices(s, b.deviceId, b.deviceName);
    WriteKeys(s, b.combo);
    SetStatus(h, s);
}

// The editor as a binding; false (with a message) when something is missing or the keys are taken.
bool ReadEditor(HWND h, State& s, int skip, Binding& out) {
    Binding b;
    b.action = (Action)SendMessageW(s.action, CB_GETCURSEL, 0, 0);
    b.combo = ReadKeys(s);
    if (skip >= 0) b.enabled = s.list[skip].enabled;
    if (hotkeys::NeedsDevice(b.action)) {
        int d = (int)SendMessageW(s.device, CB_GETCURSEL, 0, 0);
        if (d < 0 || d >= (int)s.deviceChoiceIds.size()) {
            MessageBoxW(h, T(L"Choose a device for this shortcut."), T(L"Keyboard shortcuts"), MB_OK | MB_ICONINFORMATION);
            return false;
        }
        b.deviceId = s.deviceChoiceIds[d];
        b.deviceName = s.deviceChoiceNames[d];
    }
    Level level = Level::Neutral;
    std::wstring why = Judge(h, s, b.combo, skip, level);
    if (level == Level::Neutral || level == Level::Bad) {
        MessageBoxW(h, why.c_str(), T(L"Keyboard shortcuts"), MB_OK | MB_ICONINFORMATION);
        SetFocus(s.keys);
        return false;
    }
    out = b;
    return true;
}

HWND Make(HWND parent, const wchar_t* cls, const wchar_t* text, DWORD style, int x, int y, int w, int hgt, int id, HFONT font,
          DWORD ex = 0) {
    const int dpi = GetDpiForWindow(parent);
    auto sc = [dpi](int v) { return MulDiv(v, dpi, 96); };
    HWND c = CreateWindowExW(ex, cls, text, WS_CHILD | WS_VISIBLE | style, sc(x), sc(y), sc(w), sc(hgt), parent,
                             (HMENU)(INT_PTR)id, GetModuleHandleW(nullptr), nullptr);
    SendMessageW(c, WM_SETFONT, (WPARAM)font, TRUE);
    return c;
}

void AddColumn(HWND list, int index, const wchar_t* title, int width) {
    LVCOLUMNW col{};
    col.mask = LVCF_TEXT | LVCF_WIDTH;
    col.pszText = const_cast<wchar_t*>(title);
    col.cx = MulDiv(width, GetDpiForWindow(list), 96);
    SendMessageW(list, LVM_INSERTCOLUMNW, index, (LPARAM)&col);
}

void Create(HWND h, State& s) {
    const int dpi = GetDpiForWindow(h);
    NONCLIENTMETRICSW ncm{ sizeof(ncm) };
    SystemParametersInfoForDpi(SPI_GETNONCLIENTMETRICS, sizeof(ncm), &ncm, 0, dpi);
    s.font = CreateFontIndirectW(&ncm.lfMessageFont);
    ncm.lfMessageFont.lfWeight = FW_SEMIBOLD;
    s.bold = CreateFontIndirectW(&ncm.lfMessageFont);
    s.devices = audio_mute::ListDevices();

    Make(h, L"STATIC", T(L"Your shortcuts (tick to turn on)"), 0, 16, 12, 600, 20, 0, s.bold);
    s.bindings = Make(h, WC_LISTVIEWW, L"", WS_TABSTOP | WS_BORDER | LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS | LVS_NOSORTHEADER,
                      16, 34, 768, 150, IDC_LIST, s.font);
    ListView_SetExtendedListViewStyle(s.bindings, LVS_EX_FULLROWSELECT | LVS_EX_CHECKBOXES | LVS_EX_DOUBLEBUFFER);
    AddColumn(s.bindings, 0, T(L"Action"), 280);
    AddColumn(s.bindings, 1, T(L"Device"), 230);
    AddColumn(s.bindings, 2, T(L"Shortcut"), 130);
    AddColumn(s.bindings, 3, T(L"Status"), 120);

    Make(h, L"STATIC", T(L"Action:"), SS_CENTERIMAGE, 16, 196, 80, 24, 0, s.font);
    s.action = Make(h, WC_COMBOBOXW, L"", WS_TABSTOP | WS_VSCROLL | CBS_DROPDOWNLIST, 100, 196, 380, 200, IDC_ACTION, s.font);
    for (Action a : { Action::MicMute, Action::Deafen, Action::MuteDevice, Action::DefaultDevice })
        SendMessageW(s.action, CB_ADDSTRING, 0, (LPARAM)ActionText(a));
    SendMessageW(s.action, CB_SETCURSEL, 0, 0);
    Make(h, L"STATIC", T(L"Device:"), SS_CENTERIMAGE, 16, 228, 80, 24, 0, s.font);
    s.device = Make(h, WC_COMBOBOXW, L"", WS_TABSTOP | WS_VSCROLL | CBS_DROPDOWNLIST, 100, 228, 380, 300, IDC_DEVICE, s.font);
    Make(h, L"STATIC", T(L"Keys:"), SS_CENTERIMAGE, 16, 260, 80, 24, 0, s.font);
    s.keys = Make(h, HOTKEY_CLASSW, L"", WS_TABSTOP | WS_BORDER, 100, 260, 220, 24, IDC_KEYS, s.font);
    // Keys without Ctrl or Alt would take over normal typing: such presses get Ctrl+Alt added.
    SendMessageW(s.keys, HKM_SETRULES, HKCOMB_NONE | HKCOMB_S, MAKELPARAM(HOTKEYF_CONTROL | HOTKEYF_ALT, 0));
    s.status = Make(h, L"STATIC", L"", SS_LEFT, 330, 258, 454, 40, IDC_STATUS, s.font);
    Make(h, L"BUTTON", T(L"Add as a new shortcut"), WS_TABSTOP, 100, 300, 190, 28, IDC_ADD, s.font);
    Make(h, L"BUTTON", T(L"Save to the selected one"), WS_TABSTOP, 298, 300, 190, 28, IDC_UPDATE, s.font);
    Make(h, L"BUTTON", T(L"Remove the selected one"), WS_TABSTOP, 496, 300, 190, 28, IDC_REMOVE, s.font);

    Make(h, L"STATIC", L"", SS_ETCHEDHORZ, 16, 344, 768, 2, 0, s.font);
    Make(h, L"STATIC", T(L"Is a shortcut already used? Search the shortcuts of Windows and common apps:"), 0, 16, 356, 768, 20, 0, s.bold);
    s.search = Make(h, L"EDIT", L"", WS_TABSTOP | ES_AUTOHSCROLL, 16, 380, 400, 24, IDC_SEARCH, s.font, WS_EX_CLIENTEDGE);
    SendMessageW(s.search, EM_SETCUEBANNER, TRUE, (LPARAM)T(L"Keys or words, e.g. Ctrl+Alt+M, Win+Shift, screenshot"));
    s.count = Make(h, L"STATIC", L"", SS_CENTERIMAGE, 428, 380, 356, 24, IDC_COUNT, s.font);
    s.catalog = Make(h, WC_LISTVIEWW, L"", WS_TABSTOP | WS_BORDER | LVS_REPORT | LVS_SINGLESEL | LVS_NOSORTHEADER, 16, 412, 768, 210,
                     IDC_CATALOG, s.font);
    ListView_SetExtendedListViewStyle(s.catalog, LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER);
    AddColumn(s.catalog, 0, T(L"Shortcut"), 170);
    AddColumn(s.catalog, 1, T(L"What it does"), 370);
    AddColumn(s.catalog, 2, T(L"Where"), 200);
    Make(h, L"STATIC",
         T(L"From Microsoft's list of Windows shortcuts and the default shortcuts of common apps. A shortcut that isn't listed can still belong to an app; the line next to Keys checks the apps running now."),
         0, 16, 628, 768, 34, 0, s.font);
    Make(h, L"BUTTON", T(L"Save"), WS_TABSTOP | BS_DEFPUSHBUTTON, 598, 668, 90, 28, IDOK, s.font);
    Make(h, L"BUTTON", T(L"Cancel"), WS_TABSTOP, 694, 668, 90, 28, IDCANCEL, s.font);

    FillBindings(h, s, s.list.empty() ? -1 : 0);
    if (!s.list.empty()) LoadEditor(h, s, 0);
    else { FillDevices(s, L"", L""); SetStatus(h, s); }
    FillCatalog(s);
}

LRESULT CALLBACK Proc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_NCCREATE) {
        SetWindowLongPtrW(h, GWLP_USERDATA, (LONG_PTR)reinterpret_cast<CREATESTRUCTW*>(lp)->lpCreateParams);
        return TRUE;
    }
    State* s = Get(h);
    if (!s) return DefWindowProcW(h, msg, wp, lp);
    switch (msg) {
        case WM_CREATE:
            Create(h, *s);
            return 0;
        case WM_CTLCOLORSTATIC:
            if ((HWND)lp == s->status) {
                HDC dc = (HDC)wp;
                COLORREF c = s->level == Level::Good ? RGB(16, 124, 16)
                           : s->level == Level::Warn ? RGB(157, 93, 0)
                           : s->level == Level::Bad  ? RGB(196, 43, 28)
                                                     : GetSysColor(COLOR_WINDOWTEXT);
                SetTextColor(dc, c);
                SetBkColor(dc, GetSysColor(COLOR_BTNFACE));
                return (LRESULT)GetSysColorBrush(COLOR_BTNFACE);
            }
            break;
        case WM_NOTIFY: {
            auto* hdr = reinterpret_cast<NMHDR*>(lp);
            if (hdr->idFrom == IDC_LIST && hdr->code == LVN_ITEMCHANGED && !s->filling) {
                auto* nm = reinterpret_cast<NMLISTVIEW*>(lp);
                if (nm->iItem < 0 || nm->iItem >= (int)s->list.size()) break;
                if ((nm->uChanged & LVIF_STATE) && ((nm->uNewState ^ nm->uOldState) & LVIS_STATEIMAGEMASK)) {
                    s->list[nm->iItem].enabled = ListView_GetCheckState(s->bindings, nm->iItem) != FALSE;
                    std::wstring st = !s->list[nm->iItem].enabled ? T(L"Off")
                                    : KeyFree(h, s->list[nm->iItem].combo) ? T(L"On") : T(L"Keys used elsewhere");
                    ListView_SetItemText(s->bindings, nm->iItem, 3, const_cast<wchar_t*>(st.c_str()));
                }
                if ((nm->uChanged & LVIF_STATE) && (nm->uNewState & LVIS_SELECTED) && !(nm->uOldState & LVIS_SELECTED))
                    LoadEditor(h, *s, nm->iItem);
                BOOL any = Selected(*s) >= 0;
                EnableWindow(GetDlgItem(h, IDC_UPDATE), any);
                EnableWindow(GetDlgItem(h, IDC_REMOVE), any);
            }
            break;
        }
        case WM_COMMAND: {
            int id = LOWORD(wp), code = HIWORD(wp);
            if (id == IDC_KEYS && code == EN_CHANGE) {
                SetStatus(h, *s);
                Combo c = ReadKeys(*s);
                if (c.vk) { SetWindowTextW(s->search, hotkeys::ComboText(c).c_str()); }  // show what uses it
                return 0;
            }
            if (id == IDC_SEARCH && code == EN_CHANGE) { FillCatalog(*s); return 0; }
            if (id == IDC_ACTION && code == CBN_SELCHANGE) { FillDevices(*s, L"", L""); return 0; }
            if (id == IDC_ADD) {
                Binding b;
                if (ReadEditor(h, *s, -1, b)) {
                    s->list.push_back(b);
                    FillBindings(h, *s, (int)s->list.size() - 1);
                    SetStatus(h, *s);
                }
                return 0;
            }
            if (id == IDC_UPDATE) {
                int sel = Selected(*s);
                Binding b;
                if (sel >= 0 && ReadEditor(h, *s, sel, b)) {
                    s->list[sel] = b;
                    FillBindings(h, *s, sel);
                    SetStatus(h, *s);
                }
                return 0;
            }
            if (id == IDC_REMOVE) {
                int sel = Selected(*s);
                if (sel >= 0) {
                    s->list.erase(s->list.begin() + sel);
                    FillBindings(h, *s, std::min(sel, (int)s->list.size() - 1));
                    if (Selected(*s) >= 0) LoadEditor(h, *s, Selected(*s));
                    else SetStatus(h, *s);
                }
                return 0;
            }
            if (id == IDOK) { s->accepted = true; DestroyWindow(h); return 0; }
            if (id == IDCANCEL) { DestroyWindow(h); return 0; }
            break;
        }
        case WM_CLOSE:
            DestroyWindow(h);
            return 0;
        case WM_DESTROY:
            if (s->font) DeleteObject(s->font);
            if (s->bold) DeleteObject(s->bold);
            s->font = s->bold = nullptr;
            return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}

}  // namespace

bool Show(HWND owner, std::vector<Binding>& bindings) {
    INITCOMMONCONTROLSEX icc{ sizeof(icc), ICC_LISTVIEW_CLASSES | ICC_HOTKEY_CLASS | ICC_STANDARD_CLASSES };
    InitCommonControlsEx(&icc);
    HINSTANCE inst = GetModuleHandleW(nullptr);
    WNDCLASSEXW wc{ sizeof(wc) };
    wc.hInstance = inst;
    wc.lpfnWndProc = Proc;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(1));
    wc.lpszClassName = kWindowClass;
    if (!RegisterClassExW(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) return false;

    POINT p{};
    GetCursorPos(&p);
    HMONITOR monitor = MonitorFromPoint(p, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi{ sizeof(mi) };
    RECT area{};
    if (GetMonitorInfoW(monitor, &mi)) area = mi.rcWork;
    else SystemParametersInfoW(SPI_GETWORKAREA, 0, &area, 0);
    UINT dpi = 96;
    using GetDpiForMonitorFn = HRESULT(WINAPI*)(HMONITOR, int, UINT*, UINT*);
    if (HMODULE shcore = LoadLibraryW(L"shcore.dll")) {
        UINT dx = 96, dy = 96;
        if (auto fn = (GetDpiForMonitorFn)GetProcAddress(shcore, "GetDpiForMonitor"); fn && SUCCEEDED(fn(monitor, 0, &dx, &dy))) dpi = dx;
        FreeLibrary(shcore);
    }
    const DWORD style = WS_CAPTION | WS_SYSMENU | WS_POPUP, exStyle = WS_EX_DLGMODALFRAME | WS_EX_APPWINDOW;
    RECT r{ 0, 0, MulDiv(800, dpi, 96), MulDiv(710, dpi, 96) };
    AdjustWindowRectExForDpi(&r, style, FALSE, exStyle, dpi);
    const int width = r.right - r.left, height = r.bottom - r.top;
    int x = std::max(area.left + ((area.right - area.left - width) / 2), area.left);
    int y = std::max(area.top + ((area.bottom - area.top - height) / 2), area.top);

    State state;
    state.list = bindings;
    HWND dialog = CreateWindowExW(exStyle | (i18n::Rtl() ? WS_EX_LAYOUTRTL : 0), kWindowClass, T(L"Keyboard shortcuts"), style, x, y,
                                  width, height, owner, nullptr, inst, &state);
    if (!dialog) return false;
    const bool ownerEnabled = owner && IsWindowEnabled(owner);
    if (ownerEnabled) EnableWindow(owner, FALSE);
    ShowWindow(dialog, SW_SHOW);
    UpdateWindow(dialog);
    SetForegroundWindow(dialog);
    MSG msg{};
    while (IsWindow(dialog)) {
        BOOL code = GetMessageW(&msg, nullptr, 0, 0);
        if (code <= 0) {
            if (code == 0) PostQuitMessage((int)msg.wParam);
            break;
        }
        // Enter in the search box or the key box should not close the window.
        if (msg.message == WM_KEYDOWN && msg.wParam == VK_RETURN && (msg.hwnd == state.search || msg.hwnd == state.keys)) continue;
        if (!IsDialogMessageW(dialog, &msg)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
    if (IsWindow(dialog)) DestroyWindow(dialog);
    if (ownerEnabled) EnableWindow(owner, TRUE);
    if (state.accepted) bindings = state.list;
    return state.accepted;
}

}  // namespace shortcuts_dialog
