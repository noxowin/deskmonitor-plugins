// Now playing: Windows.Media.Control (GlobalSystemMediaTransportControlsSessionManager) through the raw WinRT
// ABI. MinGW has no windows.media.control.h, so the interfaces are declared here from the Windows SDK IDL
// (10.0.22621, UniversalApiContract 7), the same way the Bluetooth drivers declare theirs.
#include "media_session.h"

#include <eventtoken.h>
#include <inspectable.h>
#include <roapi.h>
#include <winstring.h>
#include <shobjidl.h>
#include <wincodec.h>

#include <atomic>
#include <map>
#include <mutex>

// ---- ABI declarations ------------------------------------------------------------------------------
// In a named namespace on purpose: GCC treats classes in an anonymous namespace as fully known to this file, and
// since nothing here implements these interfaces it would turn calls on them into calls to nowhere.
namespace media_session_abi {
const GUID kIidUnknown = { 0x00000000, 0x0000, 0x0000, { 0xc0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46 } };
const GUID kIidAgile = { 0x94ea2b94, 0xe9cc, 0x49e0, { 0xc0, 0xff, 0xee, 0x64, 0xca, 0x8f, 0x5b, 0x90 } };
const GUID kIidAsyncInfo = { 0x00000036, 0x0000, 0x0000, { 0xc0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46 } };
const GUID kIidManagerStatics = { 0x2050c4ee, 0x11a0, 0x57de, { 0xae, 0xd7, 0xc9, 0x7c, 0x70, 0x33, 0x82, 0x45 } };
// ITypedEventHandler<Session, MediaPropertiesChangedEventArgs> / <Session, PlaybackInfoChangedEventArgs>
const GUID kIidPropsHandler = { 0x0f2ce2b7, 0xafa7, 0x5ed0, { 0x8c, 0xb6, 0x8c, 0x40, 0xcf, 0x9b, 0x3a, 0x5f } };
const GUID kIidPlaybackHandler = { 0x2bdf1426, 0xd41f, 0x5896, { 0x89, 0x7f, 0xef, 0xc0, 0xb0, 0xfa, 0x73, 0x92 } };
// ITypedEventHandler<Manager, CurrentSessionChangedEventArgs> / <Manager, SessionsChangedEventArgs>
const GUID kIidCurrentHandler = { 0x228bd0ed, 0x1fa2, 0x5e9b, { 0xa6, 0xec, 0x42, 0x56, 0x61, 0x73, 0x10, 0x3b } };
const GUID kIidSessionsHandler = { 0x2e2a8630, 0xdc8c, 0x530a, { 0x97, 0x46, 0xbc, 0x98, 0x4d, 0x4b, 0x02, 0x9e } };
// WIC and the shell, declared here so no import library is needed for their GUIDs.
const GUID kClsidWicFactory = { 0xcacaf262, 0x9370, 0x4615, { 0xa1, 0x3b, 0x9f, 0x55, 0x39, 0xda, 0x4c, 0x0a } };
const GUID kIidWicFactory = { 0xec5ec8a9, 0xc395, 0x4314, { 0x9c, 0x77, 0x54, 0xd7, 0xa9, 0x35, 0xff, 0x70 } };
const GUID kFormatPbgra = { 0x6fddc324, 0x4e03, 0x4bfe, { 0xb1, 0x85, 0x3d, 0x77, 0x76, 0x8d, 0xc9, 0x10 } };
const GUID kIidStream = { 0x0000000c, 0x0000, 0x0000, { 0xc0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46 } };
const GUID kFolderApps = { 0x1e87508d, 0x89c2, 0x42f0, { 0x8a, 0x7e, 0x64, 0x5a, 0x0f, 0x50, 0xca, 0x58 } };
const GUID kIidShellItem = { 0x43826d1e, 0xe718, 0x42ee, { 0xbc, 0x55, 0xa1, 0xe2, 0x61, 0xc3, 0x7b, 0xfe } };

struct IAsyncInfoAbi : IInspectable {
    virtual HRESULT STDMETHODCALLTYPE get_Id(UINT32*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_Status(INT32*) = 0;  // 0 started, 1 completed, 2 canceled, 3 error
    virtual HRESULT STDMETHODCALLTYPE get_ErrorCode(HRESULT*) = 0;
    virtual HRESULT STDMETHODCALLTYPE Cancel() = 0;
    virtual HRESULT STDMETHODCALLTYPE Close() = 0;
};

template <class T> struct IAsyncOp : IInspectable {  // IAsyncOperation<T>
    virtual HRESULT STDMETHODCALLTYPE put_Completed(IUnknown*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_Completed(IUnknown**) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetResults(T*) = 0;
};

struct IStreamReference : IInspectable {  // Windows.Storage.Streams.IRandomAccessStreamReference
    virtual HRESULT STDMETHODCALLTYPE OpenReadAsync(IAsyncOp<IInspectable*>**) = 0;
};

struct IPlaybackControls : IInspectable {
    virtual HRESULT STDMETHODCALLTYPE get_IsPlayEnabled(BYTE*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_IsPauseEnabled(BYTE*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_IsStopEnabled(BYTE*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_IsRecordEnabled(BYTE*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_IsFastForwardEnabled(BYTE*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_IsRewindEnabled(BYTE*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_IsNextEnabled(BYTE*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_IsPreviousEnabled(BYTE*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_IsChannelUpEnabled(BYTE*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_IsChannelDownEnabled(BYTE*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_IsPlayPauseToggleEnabled(BYTE*) = 0;
    // (shuffle, repeat, rate and position follow; not used)
};

struct IPlaybackInfo : IInspectable {
    virtual HRESULT STDMETHODCALLTYPE get_Controls(IPlaybackControls**) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_PlaybackStatus(INT32*) = 0;  // 0 closed, 1 opened, 2 changing, 3 stopped, 4 playing, 5 paused
    // (type, repeat mode, rate and shuffle follow; not used)
};

struct IMediaProperties : IInspectable {
    virtual HRESULT STDMETHODCALLTYPE get_Title(HSTRING*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_Subtitle(HSTRING*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_AlbumArtist(HSTRING*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_Artist(HSTRING*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_AlbumTitle(HSTRING*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_TrackNumber(INT32*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_Genres(IInspectable**) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_AlbumTrackCount(INT32*) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_PlaybackType(IInspectable**) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_Thumbnail(IStreamReference**) = 0;
};

using BoolOp = IAsyncOp<BYTE>;
struct ISession : IInspectable {
    virtual HRESULT STDMETHODCALLTYPE get_SourceAppUserModelId(HSTRING*) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryGetMediaPropertiesAsync(IAsyncOp<IMediaProperties*>**) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetTimelineProperties(IInspectable**) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetPlaybackInfo(IPlaybackInfo**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryPlayAsync(BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryPauseAsync(BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryStopAsync(BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryRecordAsync(BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryFastForwardAsync(BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryRewindAsync(BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TrySkipNextAsync(BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TrySkipPreviousAsync(BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryChangeChannelUpAsync(BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryChangeChannelDownAsync(BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryTogglePlayPauseAsync(BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryChangeAutoRepeatModeAsync(INT32, BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryChangePlaybackRateAsync(DOUBLE, BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryChangeShuffleActiveAsync(BYTE, BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE TryChangePlaybackPositionAsync(INT64, BoolOp**) = 0;
    virtual HRESULT STDMETHODCALLTYPE add_TimelinePropertiesChanged(IUnknown*, EventRegistrationToken*) = 0;
    virtual HRESULT STDMETHODCALLTYPE remove_TimelinePropertiesChanged(EventRegistrationToken) = 0;
    virtual HRESULT STDMETHODCALLTYPE add_PlaybackInfoChanged(IUnknown*, EventRegistrationToken*) = 0;
    virtual HRESULT STDMETHODCALLTYPE remove_PlaybackInfoChanged(EventRegistrationToken) = 0;
    virtual HRESULT STDMETHODCALLTYPE add_MediaPropertiesChanged(IUnknown*, EventRegistrationToken*) = 0;
    virtual HRESULT STDMETHODCALLTYPE remove_MediaPropertiesChanged(EventRegistrationToken) = 0;
};

struct ISessionList : IInspectable {  // IVectorView<GlobalSystemMediaTransportControlsSession>
    virtual HRESULT STDMETHODCALLTYPE GetAt(UINT32, ISession**) = 0;
    virtual HRESULT STDMETHODCALLTYPE get_Size(UINT32*) = 0;
};

struct IManager : IInspectable {
    virtual HRESULT STDMETHODCALLTYPE GetCurrentSession(ISession**) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetSessions(ISessionList**) = 0;
    virtual HRESULT STDMETHODCALLTYPE add_CurrentSessionChanged(IUnknown*, EventRegistrationToken*) = 0;
    virtual HRESULT STDMETHODCALLTYPE remove_CurrentSessionChanged(EventRegistrationToken) = 0;
    virtual HRESULT STDMETHODCALLTYPE add_SessionsChanged(IUnknown*, EventRegistrationToken*) = 0;
    virtual HRESULT STDMETHODCALLTYPE remove_SessionsChanged(EventRegistrationToken) = 0;
};

struct IManagerStatics : IInspectable {
    virtual HRESULT STDMETHODCALLTYPE RequestAsync(IAsyncOp<IManager*>**) = 0;
};

}  // namespace media_session_abi

namespace {
using namespace media_session_abi;

// ---- state -----------------------------------------------------------------------------------------
enum : LONG { kSessions = 1, kProps = 2, kPlayback = 4 };

std::mutex g_lock;  // g_snap, g_commands, g_notify
media_session::Snapshot g_snap;
std::vector<media_session::Command> g_commands;
HWND g_notify;
UINT g_msg;
HANDLE g_thread, g_stop, g_wake;  // the events live for the whole process: late event callbacks may still set g_wake
std::atomic<LONG> g_flags{ 0 };

template <class T> void Release(T*& p) {
    if (p) p->Release();
    p = nullptr;
}

std::wstring FromHString(HSTRING s) {
    UINT32 n = 0;
    const wchar_t* p = WindowsGetStringRawBuffer(s, &n);
    std::wstring r(p ? p : L"", n);
    WindowsDeleteString(s);
    return r;
}

// One event handler class for all four events: each just notes what changed and wakes the worker.
class Handler : public IUnknown {
public:
    Handler(const GUID& iid, LONG flag) : iid_(iid), flag_(flag) {}
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** out) override {
        if (!out) return E_POINTER;
        if (IsEqualGUID(riid, kIidUnknown) || IsEqualGUID(riid, kIidAgile) || IsEqualGUID(riid, iid_)) {
            *out = this;
            AddRef();
            return S_OK;
        }
        *out = nullptr;
        return E_NOINTERFACE;
    }
    ULONG STDMETHODCALLTYPE AddRef() override { return ++ref_; }
    ULONG STDMETHODCALLTYPE Release() override {
        ULONG r = --ref_;
        if (!r) delete this;
        return r;
    }
    virtual HRESULT STDMETHODCALLTYPE Invoke(IInspectable*, IInspectable*) {
        g_flags |= flag_;
        SetEvent(g_wake);
        return S_OK;
    }

private:
    virtual ~Handler() = default;
    std::atomic<ULONG> ref_{ 1 };
    GUID iid_;
    LONG flag_;
};

// Waits for a WinRT async operation (on this worker thread, so polling the status is fine); false on error,
// timeout or Stop().
template <class T> bool Await(IAsyncOp<T>* op, T* result, DWORD timeoutMs = 5000) {
    if (!op) return false;
    void* raw = nullptr;  // out-pointers go through a real void*: writing a typed pointer through void** breaks strict aliasing
    bool ok = false;
    if (SUCCEEDED(op->QueryInterface(kIidAsyncInfo, &raw)) && raw) {
        auto* info = static_cast<IAsyncInfoAbi*>(raw);
        ULONGLONG until = GetTickCount64() + timeoutMs;
        INT32 status = 0;
        while (SUCCEEDED(info->get_Status(&status)) && status == 0 && GetTickCount64() < until)
            if (WaitForSingleObject(g_stop, 5) == WAIT_OBJECT_0) break;
        if (status == 1) ok = SUCCEEDED(op->GetResults(result));
        else if (status == 0) info->Cancel();
        info->Release();
    }
    op->Release();
    return ok;
}

// "Google Chrome", "Spotify", "Firefox" ... from the session's AppUserModelID, via the Start menu's app list.
std::wstring AppName(const std::wstring& aumid) {
    static std::map<std::wstring, std::wstring> cache;
    auto it = cache.find(aumid);
    if (it != cache.end()) return it->second;
    std::wstring name;
    void* raw = nullptr;
    if (!aumid.empty() && SUCCEEDED(SHCreateItemInKnownFolder(kFolderApps, 0, aumid.c_str(), kIidShellItem, &raw)) && raw) {
        auto* item = static_cast<IShellItem*>(raw);
        wchar_t* s = nullptr;
        if (SUCCEEDED(item->GetDisplayName(SIGDN_NORMALDISPLAY, &s)) && s) {
            name = s;
            CoTaskMemFree(s);
        }
        item->Release();
    }
    if (name.empty()) {
        // Not in the app list: well-known ids, else the bare id ("Spotify.exe" -> "Spotify", packaged ids up to '_').
        static const std::pair<const wchar_t*, const wchar_t*> known[] = {
            { L"308046B0AF4A39CB", L"Firefox" }, { L"MSEdge", L"Microsoft Edge" }, { L"Chrome", L"Google Chrome" },
            { L"Spotify.exe", L"Spotify" },
        };
        for (const auto& k : known)
            if (!_wcsicmp(aumid.c_str(), k.first)) name = k.second;
        if (name.empty()) {
            name = aumid;
            size_t bang = name.find(L'!');
            if (bang != std::wstring::npos) name.erase(bang);
            size_t under = name.find(L'_');
            if (under != std::wstring::npos) name.erase(under);
            size_t dot = name.rfind(L'.');
            if (dot != std::wstring::npos && !_wcsicmp(name.c_str() + dot, L".exe")) name.erase(dot);
            else if (dot != std::wstring::npos && dot + 1 < name.size()) name.erase(0, dot + 1);  // "AppleInc.AppleMusicWin"
        }
    }
    cache[aumid] = name;
    return name;
}

using CreateStreamFn = HRESULT(WINAPI*)(IUnknown*, REFIID, void**);

// The cover art, centre-cropped to a square and scaled to kArt x kArt premultiplied BGRA.
constexpr int kArt = 192;
std::vector<uint32_t> LoadArt(IWICImagingFactory* wic, IStreamReference* ref) {
    std::vector<uint32_t> px;
    static CreateStreamFn createStream = [] {
        HMODULE m = LoadLibraryExW(L"shcore.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
        return m ? reinterpret_cast<CreateStreamFn>(reinterpret_cast<void*>(GetProcAddress(m, "CreateStreamOverRandomAccessStream"))) : nullptr;
    }();
    if (!wic || !ref || !createStream) return px;
    IAsyncOp<IInspectable*>* op = nullptr;
    IInspectable* winrtStream = nullptr;
    if (FAILED(ref->OpenReadAsync(&op)) || !Await(op, &winrtStream) || !winrtStream) return px;
    void* rawStream = nullptr;
    if (FAILED(createStream(winrtStream, kIidStream, &rawStream))) rawStream = nullptr;
    IStream* stream = static_cast<IStream*>(rawStream);
    IWICBitmapDecoder* dec = nullptr;
    IWICBitmapFrameDecode* frame = nullptr;
    IWICBitmapClipper* clip = nullptr;
    IWICBitmapScaler* scale = nullptr;
    IWICFormatConverter* conv = nullptr;
    UINT w = 0, h = 0;
    if (stream &&
        SUCCEEDED(wic->CreateDecoderFromStream(stream, nullptr, WICDecodeMetadataCacheOnLoad, &dec)) &&
        SUCCEEDED(dec->GetFrame(0, &frame)) && SUCCEEDED(frame->GetSize(&w, &h)) && w && h &&
        SUCCEEDED(wic->CreateBitmapClipper(&clip))) {
        UINT side = w < h ? w : h;
        WICRect r{ (INT)((w - side) / 2), (INT)((h - side) / 2), (INT)side, (INT)side };
        if (SUCCEEDED(clip->Initialize(frame, &r)) && SUCCEEDED(wic->CreateBitmapScaler(&scale)) &&
            SUCCEEDED(scale->Initialize(clip, kArt, kArt, WICBitmapInterpolationModeFant)) &&
            SUCCEEDED(wic->CreateFormatConverter(&conv)) &&
            SUCCEEDED(conv->Initialize(scale, kFormatPbgra, WICBitmapDitherTypeNone, nullptr, 0, WICBitmapPaletteTypeCustom))) {
            px.resize((size_t)kArt * kArt);
            if (FAILED(conv->CopyPixels(nullptr, kArt * 4, kArt * kArt * 4, reinterpret_cast<BYTE*>(px.data())))) px.clear();
        }
    }
    Release(conv);
    Release(scale);
    Release(clip);
    Release(frame);
    Release(dec);
    Release(stream);
    Release(winrtStream);
    return px;
}

void Publish(media_session::Snapshot s) {
    HWND notify;
    {
        std::lock_guard<std::mutex> l(g_lock);
        if (s.art != g_snap.art) s.artVersion = g_snap.artVersion + 1;
        else s.artVersion = g_snap.artVersion;
        bool same = s.active == g_snap.active && s.title == g_snap.title && s.artist == g_snap.artist && s.album == g_snap.album &&
                    s.app == g_snap.app && s.playing == g_snap.playing && s.canPrevious == g_snap.canPrevious &&
                    s.canPlayPause == g_snap.canPlayPause && s.canNext == g_snap.canNext && s.artVersion == g_snap.artVersion;
        if (same) return;
        g_snap = std::move(s);
        notify = g_notify;
    }
    if (notify) PostMessageW(notify, g_msg, 0, 0);
}

DWORD WINAPI Worker(LPVOID) {
    HRESULT init = RoInitialize(RO_INIT_MULTITHREADED);
    IManagerStatics* statics = nullptr;
    IManager* manager = nullptr;
    IWICImagingFactory* wic = nullptr;
    ISession* session = nullptr;
    Handler* onCurrent = new Handler(kIidCurrentHandler, kSessions);
    Handler* onSessions = new Handler(kIidSessionsHandler, kSessions);
    Handler* onProps = new Handler(kIidPropsHandler, kProps);
    Handler* onPlayback = new Handler(kIidPlaybackHandler, kPlayback);
    EventRegistrationToken tCurrent{}, tSessions{}, tProps{}, tPlayback{};

    HSTRING cls = nullptr;
    const wchar_t* name = L"Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager";
    if (SUCCEEDED(WindowsCreateString(name, (UINT32)wcslen(name), &cls))) {
        void* raw = nullptr;
        if (SUCCEEDED(RoGetActivationFactory(cls, kIidManagerStatics, &raw)) && raw) {
            statics = static_cast<IManagerStatics*>(raw);
            IAsyncOp<IManager*>* op = nullptr;
            if (SUCCEEDED(statics->RequestAsync(&op))) Await(op, &manager, 10000);
        }
        WindowsDeleteString(cls);
    }
    if (manager) {
        manager->add_CurrentSessionChanged(onCurrent, &tCurrent);
        manager->add_SessionsChanged(onSessions, &tSessions);
    }
    void* rawWic = nullptr;
    if (SUCCEEDED(CoCreateInstance(kClsidWicFactory, nullptr, CLSCTX_INPROC_SERVER, kIidWicFactory, &rawWic))) wic = static_cast<IWICImagingFactory*>(rawWic);

    media_session::Snapshot cur;  // what was read last; pieces are refreshed as their events arrive
    INT32 status = 0;             // playback status of the session shown (0 = closed)
    g_flags = kSessions | kProps | kPlayback;
    HANDLE waits[2] = { g_stop, g_wake };
    while (manager) {
        LONG flags = g_flags.exchange(0);
        std::vector<media_session::Command> cmds;
        {
            std::lock_guard<std::mutex> l(g_lock);
            cmds.swap(g_commands);
        }
        if (flags & kSessions) {
            // Follow Windows' current session (the one the media keys control); else the first one that plays.
            if (session) {
                session->remove_MediaPropertiesChanged(tProps);
                session->remove_PlaybackInfoChanged(tPlayback);
                Release(session);
            }
            manager->GetCurrentSession(&session);
            if (!session) {
                ISessionList* list = nullptr;
                UINT32 n = 0;
                if (SUCCEEDED(manager->GetSessions(&list)) && list && SUCCEEDED(list->get_Size(&n)))
                    for (UINT32 i = 0; i < n; i++) {
                        ISession* s = nullptr;
                        if (FAILED(list->GetAt(i, &s)) || !s) continue;
                        IPlaybackInfo* pi = nullptr;
                        INT32 st = 0;
                        if (SUCCEEDED(s->GetPlaybackInfo(&pi)) && pi) { pi->get_PlaybackStatus(&st); pi->Release(); }
                        if (!session || st == 4) { Release(session); session = s; s = nullptr; }
                        Release(s);
                        if (st == 4) break;
                    }
                Release(list);
            }
            if (session) {
                session->add_MediaPropertiesChanged(onProps, &tProps);
                session->add_PlaybackInfoChanged(onPlayback, &tPlayback);
                HSTRING id = nullptr;
                cur.app = SUCCEEDED(session->get_SourceAppUserModelId(&id)) ? AppName(FromHString(id)) : L"";
            }
            flags |= kProps | kPlayback;
        }
        for (auto c : cmds) {
            if (!session) break;
            BoolOp* op = nullptr;
            HRESULT hr = E_FAIL;
            if (c == media_session::Command::Previous) hr = session->TrySkipPreviousAsync(&op);
            else if (c == media_session::Command::Next) hr = session->TrySkipNextAsync(&op);
            else {
                // The toggle where the source offers it, else whichever of play / pause applies.
                IPlaybackInfo* pi = nullptr;
                IPlaybackControls* pc = nullptr;
                BYTE toggle = 0;
                INT32 st = 0;
                if (SUCCEEDED(session->GetPlaybackInfo(&pi)) && pi) {
                    pi->get_PlaybackStatus(&st);
                    if (SUCCEEDED(pi->get_Controls(&pc)) && pc) { pc->get_IsPlayPauseToggleEnabled(&toggle); pc->Release(); }
                    pi->Release();
                }
                hr = toggle ? session->TryTogglePlayPauseAsync(&op) : st == 4 ? session->TryPauseAsync(&op) : session->TryPlayAsync(&op);
            }
            BYTE done = 0;
            if (SUCCEEDED(hr)) Await(op, &done);
            flags |= kPlayback;
        }
        if (!session) {
            cur = media_session::Snapshot{};
            status = 0;
        } else {
            if (flags & kProps) {
                IAsyncOp<IMediaProperties*>* op = nullptr;
                IMediaProperties* props = nullptr;
                if (SUCCEEDED(session->TryGetMediaPropertiesAsync(&op)) && Await(op, &props) && props) {
                    HSTRING s = nullptr;
                    cur.title = SUCCEEDED(props->get_Title(&s)) ? FromHString(s) : L"";
                    cur.artist = SUCCEEDED(props->get_Artist(&s)) ? FromHString(s) : L"";
                    if (cur.artist.empty() && SUCCEEDED(props->get_AlbumArtist(&s))) cur.artist = FromHString(s);
                    if (cur.artist.empty() && SUCCEEDED(props->get_Subtitle(&s))) cur.artist = FromHString(s);
                    cur.album = SUCCEEDED(props->get_AlbumTitle(&s)) ? FromHString(s) : L"";
                    IStreamReference* thumb = nullptr;
                    cur.art = SUCCEEDED(props->get_Thumbnail(&thumb)) && thumb ? LoadArt(wic, thumb) : std::vector<uint32_t>{};
                    cur.artSize = cur.art.empty() ? 0 : kArt;
                    Release(thumb);
                    props->Release();
                }
            }
            if (flags & kPlayback) {
                IPlaybackInfo* pi = nullptr;
                IPlaybackControls* pc = nullptr;
                INT32 st = 0;
                BYTE play = 0, pause = 0, toggle = 0, next = 0, prev = 0;
                if (SUCCEEDED(session->GetPlaybackInfo(&pi)) && pi) {
                    pi->get_PlaybackStatus(&st);
                    if (SUCCEEDED(pi->get_Controls(&pc)) && pc) {
                        pc->get_IsPlayEnabled(&play);
                        pc->get_IsPauseEnabled(&pause);
                        pc->get_IsPlayPauseToggleEnabled(&toggle);
                        pc->get_IsNextEnabled(&next);
                        pc->get_IsPreviousEnabled(&prev);
                        pc->Release();
                    }
                    pi->Release();
                }
                status = st;
                cur.playing = st == 4;
                cur.canPrevious = prev != 0;
                cur.canNext = next != 0;
                cur.canPlayPause = toggle || (cur.playing ? pause : play);
            }
            cur.active = status != 0 && !(cur.title.empty() && cur.artist.empty());
        }
        Publish(cur);
        if (WaitForMultipleObjects(2, waits, FALSE, INFINITE) == WAIT_OBJECT_0) break;
    }

    if (session) {
        session->remove_MediaPropertiesChanged(tProps);
        session->remove_PlaybackInfoChanged(tPlayback);
    }
    if (manager) {
        manager->remove_CurrentSessionChanged(tCurrent);
        manager->remove_SessionsChanged(tSessions);
    }
    Release(session);
    Release(manager);
    Release(statics);
    Release(wic);
    onCurrent->Release();
    onSessions->Release();
    onProps->Release();
    onPlayback->Release();
    if (SUCCEEDED(init)) RoUninitialize();
    return 0;
}

}  // namespace

namespace media_session {

void Start(HWND notify, UINT msg) {
    if (g_thread) return;
    if (!g_stop) g_stop = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!g_wake) g_wake = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    ResetEvent(g_stop);
    {
        std::lock_guard<std::mutex> l(g_lock);
        g_notify = notify;
        g_msg = msg;
        g_snap = Snapshot{};
        g_commands.clear();
    }
    g_thread = CreateThread(nullptr, 0, Worker, nullptr, 0, nullptr);
}

void Stop() {
    {
        std::lock_guard<std::mutex> l(g_lock);
        g_notify = nullptr;
    }
    if (!g_thread) return;
    SetEvent(g_stop);
    WaitForSingleObject(g_thread, 5000);
    CloseHandle(g_thread);
    g_thread = nullptr;
}

Snapshot Get() {
    std::lock_guard<std::mutex> l(g_lock);
    return g_snap;
}

void Send(Command c) {
    {
        std::lock_guard<std::mutex> l(g_lock);
        if (!g_thread) return;
        g_commands.push_back(c);
    }
    SetEvent(g_wake);
}

}  // namespace media_session
