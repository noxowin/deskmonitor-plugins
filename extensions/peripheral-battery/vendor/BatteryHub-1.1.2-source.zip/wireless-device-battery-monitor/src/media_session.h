#pragma once
// What Windows says is playing right now: the Global System Media Transport Controls (the same source as the
// media flyout above the volume slider). Covers browser media sessions (YouTube, Netflix, Spotify or Apple Music
// on the web in Chrome, Edge or Firefox), desktop apps (Spotify, Apple Music, Media Player, VLC ...) and anything
// else that reports to Windows. Runs on its own thread, reacts to Windows' change events (no polling) and posts
// `msg` to `notify` whenever the snapshot changes.
#include <windows.h>
#include <cstdint>
#include <string>
#include <vector>

namespace media_session {

struct Snapshot {
    bool active = false;       // a media session with something to show
    std::wstring title;
    std::wstring artist;       // artist, or the channel / show (may be empty)
    std::wstring album;
    std::wstring app;          // the source app's display name ("Google Chrome", "Spotify")
    bool playing = false;
    bool canPrevious = false, canPlayPause = false, canNext = false;
    // Cover art, square, premultiplied BGRA, top-down; empty when the source has none.
    std::vector<uint32_t> art;
    int artSize = 0;
    unsigned artVersion = 0;   // changes whenever the art changes
};

enum class Command { Previous, PlayPause, Next };

// Starts the worker (once). Safe to call again after Stop().
void Start(HWND notify, UINT msg);
void Stop();
Snapshot Get();
// Sent to the current session on the worker thread; the snapshot follows through the change events.
void Send(Command c);

}  // namespace media_session
